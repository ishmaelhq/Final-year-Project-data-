%
%
%  Each run gets its own results folder (table, figures, results.mat).
%  The cross-run summary goes to results_summary\ :
%    all_runs_summary.csv   one row per run: lab vs sim at baseline and peak GIC
%    summary_vs_gic.png     key metrics vs measured peak GIC, both loadings

clear; close all; clc;

%% ===================== STEP 1: folders =====================
simDir = 'C:\Users\Student\Downloads\GIC analysis\GIC_Investigation.gf81_x86';  % folder with the .inf/.out files
labDir = 'C:\Users\Student\Downloads\GIC analysis\Lab data';                      % folder with the WT1800 CSVs

%% ===================== STEP 2: runs ========================
% Columns: label | PSCAD .inf | WT1800 load-analyzer CSV | Rload (ohm) | loading | level
RUNS = {
 'Low GIC, 50 \Omega',       'Gic_Low_50.inf',   'Gic_Low_50_Load.CSV',   50,  '50 ohm',  'Low'
 'Moderate GIC, 50 \Omega',  'Gic_Mod_50.inf',   'Gic_Mod_50_Load.CSV',   50,  '50 ohm',  'Moderate'
 'High GIC, 50 \Omega',      'Gic_High_50.inf',  'Gic_High_50_Load.CSV',  50,  '50 ohm',  'High'
 'Low GIC, 100 \Omega',      'Gic_Low_100.inf',  'Gic_Low_100_Load.CSV',  100, '100 ohm', 'Low'
 'Moderate GIC, 100 \Omega', 'Gic_Mod_100.inf',  'Gic_Mod_100_Load.CSV',  100, '100 ohm', 'Moderate'
 'High GIC, 100 \Omega',     'Gic_High_100.inf', 'Gic_High_100_Load.CSV', 100, '100 ohm', 'High'
};
only=[];      % [] = all runs; e.g. only = 6 to test a single run first
%% ===========================================================

if isempty(only), only = 1:size(RUNS,1); end

% ---- check all files exist before spending time on any run ----
missing = {};
for r = only
    if ~exist(fullfile(simDir, RUNS{r,2}), 'file'), missing{end+1} = fullfile(simDir, RUNS{r,2}); end %#ok<SAGROW>
    if ~exist(fullfile(labDir, RUNS{r,3}), 'file'), missing{end+1} = fullfile(labDir, RUNS{r,3}); end %#ok<SAGROW>
end
if ~isempty(missing)
    fprintf(2, 'These files were not found:\n'); fprintf(2, '   %s\n', missing{:});
    error('Fix simDir / labDir or the file names in RUNS, then run again.');
end

% ---- process each run ----
res = cell(1, size(RUNS,1));
for r = only
    cfg = gic_defaults();
    cfg.label  = RUNS{r,1};
    cfg.simInf = fullfile(simDir, RUNS{r,2});
    cfg.labCsv = fullfile(labDir, RUNS{r,3});
    cfg.Rload  = RUNS{r,4};
    [~, stem]  = fileparts(RUNS{r,2});
    cfg.outDir = fullfile(pwd, ['results_' stem]);
    tic;
    res{r} = gic_compare(cfg);
    fprintf('Run %d done in %.0f s\n', r, toc);
end

% ---- cross-run summary ----
sumDir = fullfile(pwd, 'results_summary');
if ~exist(sumDir, 'dir'), mkdir(sumDir); end
metrics = {'Igic_abs','V4rms','P4','Q1','I3_h2','I3_h4','I3_thd','V4_h3','V4_thd'};
fid = fopen(fullfile(sumDir, 'all_runs_summary.csv'), 'w');
fprintf(fid, 'Run,Loading,Level,Metric,Unit,Lab_baseline,Sim_baseline,Err_baseline_pct,Lab_peak,Sim_peak,Err_peak_pct,Lab_change,Sim_change,Err_change_pct\n');
for r = only
    T = res{r}.T;
    for m = 1:numel(metrics)
        k = find(strcmp(T(:,1), metrics{m}), 1);
        fprintf(fid, '%s,%s,%s,%s,%s,%.5g,%.5g,%.3g,%.5g,%.5g,%.3g,%.5g,%.5g,%.3g\n', ...
            strrep(RUNS{r,1}, '\Omega', 'ohm'), RUNS{r,5}, RUNS{r,6}, T{k,1:11});
    end
end
fclose(fid);
fprintf('\nSummary table: %s\n', fullfile(sumDir, 'all_runs_summary.csv'));

% ---- summary figure: metric at peak GIC vs measured peak GIC ----
plt = {'I3_h2','I3 h2 at peak (% of h1)'; 'I3_thd','I3 THD-F at peak (%)'; ...
       'Q1','Q1 at peak (var)'; 'V4_h3','V4 h3 at peak (% of h1)'; ...
       'V4_thd','V4 THD-F at peak (%)'; 'V4rms','V4 RMS at peak (V)'};
loads = unique(RUNS(only,5), 'stable');
mk = {'o','s'}; cl = [0.13 0.40 0.67; 0.80 0.30 0.15];
f = figure('Position', [60 60 1250 650], 'Visible', 'off');
for p = 1:size(plt,1)
    subplot(2,3,p); hold on; grid on; box on; lg = {};
    for L = 1:numel(loads)
        rr = only(strcmp(RUNS(only,5), loads{L}));
        xl = zeros(size(rr)); yl = xl; xs = xl; ys = xl;
        for q = 1:numel(rr)
            T = res{rr(q)}.T;
            kG = find(strcmp(T(:,1), 'Igic_abs'), 1); kM = find(strcmp(T(:,1), plt{p,1}), 1);
            xl(q) = T{kG,6}; yl(q) = T{kM,6};      % lab peak
            xs(q) = T{kG,7}; ys(q) = T{kM,7};      % sim peak
        end
        [xl, o] = sort(xl); yl = yl(o); [xs, o] = sort(xs); ys = ys(o);
        plot(xl, yl, ['-' mk{L}], 'Color', cl(L,:), 'MarkerFaceColor', cl(L,:));
        plot(xs, ys, ['--' mk{L}], 'Color', cl(L,:));
        lg = [lg, {['Lab ' loads{L}], ['Sim ' loads{L}]}]; %#ok<AGROW>
    end
    xlabel('Measured peak |I_{GIC}| (A)'); ylabel(plt{p,2});
    if p == 1, legend(lg, 'Location', 'northwest'); end
end
sgtitle_compat(f, 'Lab (solid, filled) vs PSCAD (dashed, open) at peak GIC');
print(f, fullfile(sumDir, 'summary_vs_gic.png'), '-dpng', '-r150');
close(f);
fprintf('Summary figure: %s\n', fullfile(sumDir, 'summary_vs_gic.png'));
