function idx = find_phase_channels(names, want, nWant)
%FIND_PHASE_CHANNELS  Locate PSCAD channels by name, tolerant of how PSCAD
%   labels the phases of a 3-phase output channel.
%
%   idx = find_phase_channels(S.names, 'V3', 3)   -> 3 column indices (a, b, c)
%   idx = find_phase_channels(S.names, 'Igic', 1) -> 1 column index
%   idx = find_phase_channels(S.names, {'V3a','V3b','V3c'}, 3)  explicit names
%
%   For a base name like 'V3' it accepts, in this order:
%     - the same Desc repeated 3 times ('V3','V3','V3')
%     - 'V3:1' 'V3_1' 'V3(1)' 'V3[1]' 'V3 1' 'V31' and the a/b/c or A/B/C versions
%   If nothing matches it prints every channel in the file and stops.

    if iscell(want)                                   % explicit list of names
        idx = zeros(1, numel(want));
        for k = 1:numel(want)
            j = find(strcmp(names, want{k}), 1);
            if isempty(j), fail(names, want{k}); end
            idx(k) = j;
        end
        return;
    end

    exact = find(strcmp(names, want));
    if numel(exact) == nWant
        idx = exact(:)'; return;
    end

    if nWant == 1
        j = find(strncmpi(names, want, numel(want)), 1);    % e.g. 'Igic' matches 'Igic:1'
        if isempty(j), fail(names, want); end
        idx = j; return;
    end

    pat  = ['^' regexptranslate('escape', want) '\s*[:_\(\[ ]?\s*([1-3a-cA-C])\s*[\)\]]?$'];
    idx  = zeros(1, nWant);
    for j = 1:numel(names)
        tok = regexp(names{j}, pat, 'tokens', 'once');
        if isempty(tok), continue; end
        c = lower(tok{1});
        if c >= 'a', p = double(c) - double('a') + 1; else, p = str2double(c); end
        if p >= 1 && p <= nWant && idx(p) == 0, idx(p) = j; end
    end
    if any(idx == 0), fail(names, want); end
end

function fail(names, want)
    fprintf(2, '\nChannels found in the .inf file:\n');
    fprintf(2, '   "%s"\n', names{:});
    error(['Could not find PSCAD channel "%s". Look at the list above and put the ' ...
           'exact names in gic_defaults.m (cfg.ch...).'], want);
end
