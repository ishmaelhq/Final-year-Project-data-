function S = read_pscad_out(infFile)
%READ_PSCAD_OUT  Read PSCAD Legacy (*.out + *.inf) channel output.
%
%   S = read_pscad_out('C:\...\gic_high.inf')
%
%   Output S:
%     S.t      [N x 1]  time (s)
%     S.data   [N x M]  channel values (PSCAD units, usually kV / kA)
%     S.names  {1 x M}  channel descriptions (Desc="..." in the .inf)
%     S.units  {1 x M}  units from the .inf

    % ---------- 0. .inf or .infx? ----------
    [p0, b0, e0] = fileparts(infFile);
    if strcmpi(e0, '.infx') && exist(fullfile(p0, [b0 '.inf']), 'file')
        infFile = fullfile(p0, [b0 '.inf']);          % prefer the plain-text .inf
    elseif strcmpi(e0, '.inf') && ~exist(infFile, 'file') && exist(fullfile(p0, [b0 '.infx']), 'file')
        infFile = fullfile(p0, [b0 '.infx']);         % only the .infx exists
    end
    if ~exist(infFile, 'file'), error('File not found: %s', infFile); end

    % ---------- 1. Parse the channel list ----------
    txt   = fileread(infFile);
    if ~isempty(strfind(lower(infFile), '.infx'))     %#ok<STREMP>
        [names, units] = parse_infx(txt, infFile);
        M = numel(names);
    else
    lines = regexp(txt, '\r?\n', 'split');
    idx = []; names = {}; units = {};
    for k = 1:numel(lines)
        L = lines{k};
        tokN = regexp(L, 'PGB\((\d+)\)', 'tokens', 'once');
        if isempty(tokN), continue; end
        tokD = regexp(L, 'Desc="([^"]*)"',  'tokens', 'once');
        tokU = regexp(L, 'Units="([^"]*)"', 'tokens', 'once');
        idx(end+1)   = str2double(tokN{1});                 %#ok<AGROW>
        names{end+1} = strtrim(tokD{1});                    %#ok<AGROW>
        if isempty(tokU), units{end+1} = ''; else, units{end+1} = tokU{1}; end %#ok<AGROW>
    end
    if isempty(idx), error('No PGB(...) channel entries found in %s', infFile); end
    [~, order] = sort(idx);
    names = names(order); units = units(order);
    M = numel(names);
    end

    % ---------- 2. Find and read the .out files ----------
    [p, base] = fileparts(infFile);      % .out files share the base name
    if isempty(p), p = '.'; end
    outs = dir(fullfile(p, [base '_*.out']));
    if isempty(outs)                      % single-file case: <name>.out
        outs = dir(fullfile(p, [base '.out']));
    end
    if isempty(outs), error('No .out files found next to %s', infFile); end
    [~, o] = sort({outs.name}); outs = outs(o);

    t = []; data = [];
    for k = 1:numel(outs)
        A = read_numeric_text(fullfile(p, outs(k).name));
        if isempty(t)
            t = A(:,1);
        else
            n = min(numel(t), size(A,1));        % guard against ragged ends
            t = t(1:n); data = data(1:n,:); A = A(1:n,:);
        end
        data = [data, A(:,2:end)];               %#ok<AGROW>
    end

    if size(data,2) < M
        error('The .inf lists %d channels but the .out files hold only %d.', M, size(data,2));
    end
    S.t = t; S.data = data(:,1:M); S.names = names; S.units = units;

    fprintf('PSCAD: %d channels, %d samples, t = %.4g..%.4g s, dt = %.3g us\n', ...
        M, numel(t), t(1), t(end), 1e6*median(diff(t)));
end

function A = read_numeric_text(f)
% Fast whitespace-delimited numeric reader that skips a header line if present.
    fid = fopen(f, 'r');
    if fid < 0, error('Cannot open %s', f); end
    first = fgetl(fid);
    vals  = str2double(regexp(strtrim(first), '\s+', 'split'));
    hdr   = any(isnan(vals));
    if hdr
        second = fgetl(fid);
        ncol = numel(regexp(strtrim(second), '\s+', 'split'));
    else
        ncol = numel(vals);
    end
    frewind(fid);
    C = textscan(fid, repmat('%f', 1, ncol), 'HeaderLines', double(hdr), ...
                 'CollectOutput', true);
    fclose(fid);
    A = C{1};
    A = A(~any(isnan(A),2), :);
end

function [names, units] = parse_infx(txt, f)
% Best-effort reader for the XML .infx channel list. Looks for XML tags that
% carry an index plus a name/desc attribute, and orders them by index.
    tags = regexp(txt, '<[^>]+>', 'match');
    idx = []; names = {}; units = {};
    for k = 1:numel(tags)
        tg = tags{k};
        ti = regexp(tg, '(?:^|\s)(?:index|idx|id)="(\d+)"', 'tokens', 'once');
        tn = regexp(tg, '(?:^|\s)(?:desc|Desc|name|Name)="([^"]*)"', 'tokens', 'once');
        if isempty(ti) || isempty(tn), continue; end
        tu = regexp(tg, '(?:^|\s)(?:units?|Units?)="([^"]*)"', 'tokens', 'once');
        idx(end+1) = str2double(ti{1});                       %#ok<AGROW>
        names{end+1} = strtrim(tn{1});                        %#ok<AGROW>
        if isempty(tu), units{end+1} = ''; else, units{end+1} = tu{1}; end %#ok<AGROW>
    end
    if isempty(idx)
        error(['Could not read the channel list from %s. Open it in Notepad and ' ...
               'paste its contents to Claude, or use the matching .inf file.'], f);
    end
    [~, o] = sort(idx); names = names(o); units = units(o);
    fprintf('Read channel list from .infx (%d channels).\n', numel(names));
end
