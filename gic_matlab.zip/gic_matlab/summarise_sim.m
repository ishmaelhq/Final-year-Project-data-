function [M, R, sig] = summarise_sim(S, cfg)

%
%   M : struct of [nb x 1] metrics (field list in summarise_lab, identical)
%   R : R.V3I3{p}, R.V4I4{p} = full wt1800_emulate output per phase p = 1..3
%   sig : the raw (scaled, windowed) waveforms, for the wavelet step

    ch = cfg.ch;

    % ----- locate channels (tolerant of PSCAD phase naming) -----
    jG  = find_phase_channels(S.names, ch.Igic, 1);
    jV3 = find_phase_channels(S.names, ch.V3, 3);
    jI3 = find_phase_channels(S.names, ch.I3, 3);
    jV4 = find_phase_channels(S.names, ch.V4, 3);
    fprintf('Channels used: Igic="%s" | V3=%s | I3=%s | V4=%s\n', S.names{jG}, ...
        strjoin(S.names(jV3), ','), strjoin(S.names(jI3), ','), strjoin(S.names(jV4), ','));

    % ----- analysis window -----
    t = S.t;
    if isempty(cfg.t_win), k = t >= cfg.t_skip;
    else,                  k = t >= cfg.t_win(1) & t < cfg.t_win(2);
    end
    if ~isempty(cfg.t_win) && t(end) < cfg.t_win(end) - 1
        warning('summarise_sim:short', ['Run ends at %.1f s but cfg.t_win ends at %.1f s - ' ...
            'only part of the GIC cycle will be analysed.'], t(end), cfg.t_win(end));
    end
    t = t(k);

    sig.t    = t;
    sig.fs   = 1/median(diff(t));
    sig.Igic = cfg.Iscale * S.data(k, jG);
    sig.V3 = cfg.Vscale * S.data(k, jV3);
    sig.I3 = cfg.Iscale * S.data(k, jI3);
    sig.V4 = cfg.Vscale * S.data(k, jV4);
    if isempty(ch.I4)                         % purely resistive load: I4 = V4 / R_load
        sig.I4 = sig.V4 / cfg.Rload;
    else
        sig.I4 = cfg.Iscale * S.data(k, find_phase_channels(S.names, ch.I4, 3));
    end

    % ----- unit sanity check (catches a wrong kV/kA scale) -----
    vr = sqrt(mean(sig.V3(:,1).^2));  ip = max(abs(sig.Igic));
    fprintf('Sanity: V3a RMS = %.1f V, |Igic| peak = %.3f A, I3a RMS = %.3f A\n', ...
        vr, ip, sqrt(mean(sig.I3(:,1).^2)));
    if vr < 20 || vr > 2000
        warning('summarise_sim:units', 'V3 RMS = %.4g V looks wrong - check cfg.Vscale.', vr);
    end
    if ip < 0.01 || ip > 50
        warning('summarise_sim:units', '|Igic| peak = %.4g A looks wrong - check cfg.Iscale.', ip);
    end

    % ----- WT1800 emulation, per phase -----
    for p = 1:3
        R.V3I3{p} = wt1800_emulate(t, sig.V3(:,p), sig.I3(:,p), cfg.f0, cfg.Tblock, cfg.hmax);
        R.V4I4{p} = wt1800_emulate(t, sig.V4(:,p), sig.I4(:,p), cfg.f0, cfg.Tblock, cfg.hmax);
    end
    nb = numel(R.V3I3{1}.tb);
    N  = round(cfg.Tblock*sig.fs);
    Ig = reshape(sig.Igic(1:nb*N), N, nb);

    % ----- metrics (same definitions as summarise_lab) -----
    hc = cfg.hcmp;
    M.t        = R.V3I3{1}.tb;
    M.Igic     = mean(Ig, 1)';                                 
    M.Igic_abs = zeros(nb,1);                                   
    for p = 1:3, M.Igic_abs = M.Igic_abs + abs(R.V3I3{p}.Idc); end

    M.V3rms = ph_mean(R.V3I3, @(r) r.Urms);
    M.V4rms = ph_mean(R.V4I4, @(r) r.Urms);
    M.I3rms = ph_mean(R.V3I3, @(r) r.Irms);
    M.I4rms = ph_mean(R.V4I4, @(r) r.Irms);
    for h = 2:5
        M.(sprintf('I3_h%d', h)) = ph_mean(R.V3I3, @(r) 100*r.Ih(:,h)./r.Ih(:,1));
    end
    M.V4_h2  = ph_mean(R.V4I4, @(r) 100*r.Uh(:,2)./r.Uh(:,1));
    M.V4_h3  = ph_mean(R.V4I4, @(r) 100*r.Uh(:,3)./r.Uh(:,1));
    M.I3_thd = ph_mean(R.V3I3, @(r) thdF(r.Ih(:,1:hc)));
    M.V3_thd = ph_mean(R.V3I3, @(r) thdF(r.Uh(:,1:hc)));
    M.V4_thd = ph_mean(R.V4I4, @(r) thdF(r.Uh(:,1:hc)));
    M.I4_thd = ph_mean(R.V4I4, @(r) thdF(r.Ih(:,1:hc)));
    M.Q1     = R.V3I3{1}.Q1 + R.V3I3{2}.Q1 + R.V3I3{3}.Q1;      % 3-ph, T2 primary
    M.P4     = R.V4I4{1}.P  + R.V4I4{2}.P  + R.V4I4{3}.P;       % 3-ph output power

    % sanity print: GIC channel vs lab-style inference
    fprintf('Sim GIC: channel peak +%.3f / %.3f A; lab-style sum|Idc| peak %.3f A\n', ...
        max(M.Igic), min(M.Igic), max(M.Igic_abs));
end

function m = ph_mean(Rc, f)
    m = (f(Rc{1}) + f(Rc{2}) + f(Rc{3}))/3;
end

function y = thdF(H)     % H = [nb x hc] harmonic RMS, col 1 = fundamental
    y = 100*sqrt(sum(H(:,2:end).^2, 2)) ./ H(:,1);
end
