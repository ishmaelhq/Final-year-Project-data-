function cfg = gic_defaults()
%GIC_DEFAULTS  Settings shared by every run. ; run_all.m adds the
%   per-run items (file paths, load resistance, label).

    % ---------- PSCAD channel names ----------
    % Use the names you gave the output channels in PSCAD. For a 3-phase channel
    % just give the base name ('V3'); the code finds the three phases itself.
    % If it cannot, it prints every channel in the .inf - then put the exact
    % names here as a list, e.g. cfg.ch.V3 = {'V3:1','V3:2','V3:3'};
    cfg.ch.Igic = 'Igic';
    cfg.ch.V3   = 'V3';        % T2 primary voltage, phase-to-neutral
    cfg.ch.I3   = 'I3';        % T2 primary current (carries the GIC)
    cfg.ch.V4   = 'V4';        % T2 output voltage
    cfg.ch.I4   = {};          % not recorded: I4 = V4 / Rload (resistive load)

    % PSCAD meters output kV and kA. 
    cfg.Vscale = 1e3;          
    cfg.Iscale = 1;            

    % ---------- WT1800 (load analyzer) element map ----------
    cfg.lab.e3 = 1:3;          % elements 1-3 = T2 primary  (V3 / I3)
    cfg.lab.e4 = 4:6;          % elements 4-6 = T2 output   (V4 / I4)

    % ---------- Processing ----------
    cfg.f0        = 50;          % Hz
    cfg.Tblock    = 0.5;         % s = WT1800 update rate (25 cycles per block)
    cfg.hmax      = 40;          % harmonics computed for the simulation
    cfg.hcmp      = 8;           % harmonics used for sim-vs-lab THD (lab logged h1..h8)
    cfg.t_win     = [70 136.7];  % s: the 2nd full GIC cycle of a 140 s run (66.7 s at 15 mHz)
    cfg.t_skip    = 2;           % s: only used if t_win = []
    cfg.base_frac = 0.05;        % 'baseline' records: |GIC| <= 5 % of peak
    cfg.peak_frac = 0.90;        % 'peak' records:     |GIC| >= 90 % of peak

    % ---------- Output ----------
    cfg.showFigs = false;        % true = leave figure windows open (slow for 6 runs)
end
