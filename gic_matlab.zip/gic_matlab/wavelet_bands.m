function W = wavelet_bands(x, fs, f0, Tblock)
%WAVELET_BANDS  MODWT multiresolution analysis of one waveform (Wavelet Toolbox).
%
%   W = wavelet_bands(I3a, fs, 50, 0.5)
%
%   Uses the maximal-overlap DWT (shift-invariant, every band stays time-aligned
%   with the signal) with db4. The level L = floor(log2(fs/f0)) puts the
%   fundamental in the last detail band D_L, so:
%     A_L        0 .. fs/2^(L+1)       -> DC / GIC offset
%     D_L        ~ f0 band             -> fundamental
%     D_(L-1)    ~ 2f0..4f0            -> h2, h3   (main saturation signature)
%     D_(L-2)    ~ 4f0..8f0            -> h4..h6
%     ...
% 
%
%   W.label  {1 x L+1}   band names
%   W.f      [L+1 x 2]   nominal band edges (Hz)
%   W.tb     [nb x 1]    block centre times (s), relative to the first sample
%   W.rms    [nb x L+1]  RMS of each band per block (same blocks as the FFT)

    x = x(:)';
    L = floor(log2(fs/f0));
    if exist('modwt', 'file') && exist('modwtmra', 'file')
        w   = modwt(x, 'db4', L);
        mra = modwtmra(w, 'db4');             % (L+1) x N, rows sum back to x
        W.method = 'Wavelet Toolbox MODWT-MRA (db4)';
    else
        % No Wavelet Toolbox: same db4 MODWT, band RMS from the coefficients.
        % (MODWT coefficients preserve energy band by band, so the band RMS
        %  curves have the same shape and meaning as the MRA version.)
        [Wc, VJ] = modwt_basic(x, L);
        mra = [Wc; VJ];
        W.method = 'modwt\_basic (db4, no toolbox)';
        fprintf('Wavelet: Wavelet Toolbox not found - using built-in db4 MODWT.\n');
    end

    W.label = cell(1, L+1); W.f = zeros(L+1, 2);
    for j = 1:L
        W.label{j} = sprintf('D%d', j);
        W.f(j,:)   = [fs/2^(j+1), fs/2^j];
    end
    W.label{L+1} = sprintf('A%d', L);
    W.f(L+1,:)   = [0, fs/2^(L+1)];

    N  = round(Tblock*fs);
    nb = floor(numel(x)/N);
    W.rms = zeros(nb, L+1); W.tb = ((0:nb-1)' + 0.5)*Tblock;
    for b = 1:nb
        k = (b-1)*N + (1:N);
        W.rms(b,:) = sqrt(mean(mra(:,k).^2, 2))';
    end
    W.mra = mra;  W.L = L;
end
