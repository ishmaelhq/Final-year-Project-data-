function T = compare_table(Ms, Ml, cfg, outCsv)
%COMPARE_TABLE  Baseline (GIC ~ 0) and peak-GIC means, simulation vs lab.
%
%   Baseline = records with Igic_abs <= cfg.base_frac * peak
%   Peak     = records with Igic_abs >= cfg.peak_frac * peak
%   Each data set uses its own peak, so the rows compare like with like.
%   Baseline rows check the TUNING (they should agree closely by design);
%   peak rows are the actual test of the model.

    f = {'Igic_abs','V3rms','V4rms','I3rms','I4rms','P4','Q1', ...
         'I3_h2','I3_h3','I3_h4','I3_h5','I3_thd','V3_thd','V4_h3','V4_thd','I4_thd'};
    u = {'A','V','V','A','A','W','var','%','%','%','%','%','%','%','%','%'};

    sb = Ms.Igic_abs <= cfg.base_frac*max(Ms.Igic_abs);
    sp = Ms.Igic_abs >= cfg.peak_frac*max(Ms.Igic_abs);
    lb = Ml.Igic_abs <= cfg.base_frac*max(Ml.Igic_abs);
    lp = Ml.Igic_abs >= cfg.peak_frac*max(Ml.Igic_abs);
    % if too few records meet a threshold, fall back to the 3 nearest records
    sb = atleast(sb, Ms.Igic_abs, 'low');  sp = atleast(sp, Ms.Igic_abs, 'high');
    lb = atleast(lb, Ml.Igic_abs, 'low');  lp = atleast(lp, Ml.Igic_abs, 'high');
    fprintf('\nRecords used: sim baseline %d, peak %d | lab baseline %d, peak %d\n', ...
        nnz(sb), nnz(sp), nnz(lb), nnz(lp));

    T = cell(numel(f), 11);
    fprintf('\n%-9s %-4s | %9s %9s %7s | %9s %9s %7s | %9s %9s %7s\n', 'Metric','Unit', ...
        'Lab base','Sim base','Err%', 'Lab peak','Sim peak','Err%', 'Lab chg','Sim chg','Err%');
    fprintf('%s\n', repmat('-', 1, 106));
    for k = 1:numel(f)
        a = mean(Ml.(f{k})(lb)); b = mean(Ms.(f{k})(sb));
        c = mean(Ml.(f{k})(lp)); d = mean(Ms.(f{k})(sp));
        e1 = 100*(b-a)/a;  e2 = 100*(d-c)/c;
        dl = c - a;  ds = d - b;  e3 = 100*(ds-dl)/dl;      % change caused by GIC (peak - baseline)
        fprintf('%-9s %-4s | %9.3f %9.3f %7.1f | %9.3f %9.3f %7.1f | %9.3f %9.3f %7.1f\n', ...
            f{k}, u{k}, a, b, e1, c, d, e2, dl, ds, e3);
        T(k,:) = {f{k}, u{k}, a, b, e1, c, d, e2, dl, ds, e3};
    end

    % Sim only: does polarity matter? (the lab cannot tell)
    pp = Ms.Igic >=  cfg.peak_frac*max(Ms.Igic);
    pn = Ms.Igic <=  cfg.peak_frac*min(Ms.Igic);
    if any(pp) && any(pn)
        fprintf('\nSim polarity check (mean at +peak vs -peak GIC):\n');
        for k = [7 8 10 12 15]
            fprintf('  %-7s +GIC %8.3f   -GIC %8.3f %s\n', f{k}, ...
                mean(Ms.(f{k})(pp)), mean(Ms.(f{k})(pn)), u{k});
        end
    end

    if nargin > 3 && ~isempty(outCsv)
        fid = fopen(outCsv, 'w');
        fprintf(fid, 'Metric,Unit,Lab_baseline,Sim_baseline,Err_baseline_pct,Lab_peak,Sim_peak,Err_peak_pct,Lab_change,Sim_change,Err_change_pct\n');
        for k = 1:size(T,1)
            fprintf(fid, '%s,%s,%.5g,%.5g,%.3g,%.5g,%.5g,%.3g,%.5g,%.5g,%.3g\n', T{k,1:11});
        end
        fclose(fid);
        fprintf('\nTable written to %s\n', outCsv);
    end
end

function m = atleast(m, x, side)
    if nnz(m) >= 3, return; end
    [~, o] = sort(x, 'ascend');
    if strcmp(side, 'high'), o = flipud(o(:)); end
    m = false(size(x)); m(o(1:min(3, numel(x)))) = true;
    warning('compare_table:few', 'Fewer than 3 %s-GIC records met the threshold; using the 3 nearest.', side);
end
