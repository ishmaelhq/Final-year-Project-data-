%% PLOT_HARMONIC_BARS  Report figures: harmonic spectra, laboratory vs simulation.
%
%  Run AFTER run_all.m (it reads the results_Gic_* folders it created).
%
%  One figure per loading per phase  ->  2 loadings x 3 phases = 6 figures.
%  Each figure: 3 rows x 2 columns, same y-scale across a row (and across both
%  loadings for the same phase, so 50 and 100 ohm can be compared directly):
%       (a) I3, Laboratory        (b) I3, Simulation        harmonic current, A
%       (c) V3, Laboratory        (d) V3, Simulation        % of fundamental
%       (e) V4, Laboratory        (f) V4, Simulation        % of fundamental%
%  Outputs in results_figures\ :
%    harm_50ohm_phaseA.pdf/.png ... harm_100ohm_phaseC.pdf/.png  (vector PDF for LaTeX)
%    harm_current_*/harm_voltage_* the same figures split: I3 only / V3+V4 only
%    harmonic_table.csv          every plotted value + the fundamentals (h1)
%    harmonic_h1_table.tex       LaTeX table of fundamentals for the captions/text

clear; close all; clc;

%% ===================== settings =====================
resRoot = pwd;                          % folder that contains results_Gic_* folders
outDir  = fullfile(pwd, 'results_figures');
loads   = {'50', '100'};                % run-name suffixes
levels  = {'Low', 'Mod', 'High'};       % run-name middles (Gic_<level>_<load>)
levelNames = {'Low', 'Moderate', 'High'};
hmax    = 7;
figW = 16; figH = 19;                   % cm - fits a single-column A4 page
fontName = 'Helvetica'; fs = 8;
% Ordinal one-hue palette (validated: monotone lightness, single hue, light end
% clears the white page). Lightest = No GIC, darkest = High. 
C = [0.525 0.714 0.937;   %  No GIC
     0.224 0.529 0.898;   %   Low
     0.110 0.361 0.671;   %  Moderate
     0.051 0.212 0.420];  %  High
%% ====================================================

if ~exist(outDir, 'dir'), mkdir(outDir); end
phases = {'A','B','C'};
qty    = {'I3','V3','V4'};
rowLab = {'I_3 harmonic current (A)', 'V_3 harmonic voltage (% of h1)', 'V_4 harmonic voltage (% of h1)'};
panel  = 'abcdef';

% ---------- gather snapshots ----------
S = struct();
for L = 1:numel(loads)
    for g = 1:numel(levels)
        f = fullfile(resRoot, sprintf('results_Gic_%s_%s', levels{g}, loads{L}), 'results.mat');
        if ~exist(f, 'file'), error('Missing %s - run run_all.m first.', f); end
        fprintf('Reading %s\n', f);
        S(L,g).H = harmonic_snapshot(f, hmax);
    end
end

% ---------- build bar data: D{L}.(src).(q)(p, h, group), group 1=No GIC..4=High ----------
D = cell(1, numel(loads));
for L = 1:numel(loads)
    for src = {'lab','sim'}
        s = src{1};
        for q = 1:3
            A = zeros(3, hmax, 4);
            A(:,:,1) = S(L,1).H.(s).base.(qty{q});                 % No GIC from the Low run
            for g = 1:3, A(:,:,g+1) = S(L,g).H.(s).peak.(qty{q}); end
            if q > 1                                               % voltages -> % of own h1
                A = 100 * A ./ repmat(A(:,1,:), [1 hmax 1]);
            end
            D{L}.(s).(qty{q}) = A;
        end
    end
end

% ---------- common y-limits per phase & row (both loadings, lab and sim) ----------
ylimv = zeros(3, 3);
for p = 1:3
    for q = 1:3
        m = 0;
        for L = 1:numel(loads)
            for s = {'lab','sim'}
                m = max(m, max(max(D{L}.(s{1}).(qty{q})(p, 2:hmax, :))));
            end
        end
        ylimv(p,q) = nicelim(m);
    end
end

% ---------- figures ----------
for L = 1:numel(loads)
    gicLab = arrayfun(@(g) S(L,g).H.gic.lab, 1:3);
    gicSim = arrayfun(@(g) S(L,g).H.gic.sim, 1:3);
    for p = 1:3
        fig = figure('Units','centimeters','Position',[2 2 figW figH], 'Color','w');
        axL = [0.11 0.585]; axW = 0.385; axH = 0.215; axB = [0.69 0.385 0.08];
        for q = 1:3
            for c = 1:2
                s = {'lab','sim'}; s = s{c};
                ax = axes('Position', [axL(c) axB(q) axW axH]);   % fixed grid, legend strip on top
                Y = squeeze(D{L}.(s).(qty{q})(p, 2:hmax, :));      % [6 orders x 4 groups]
                b = bar(2:hmax, Y, 0.85, 'grouped');
                for k = 1:4, set(b(k), 'FaceColor', C(k,:), 'EdgeColor', 'none'); end
                set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
                    'XTick', 2:hmax, 'YGrid', 'on', 'XGrid', 'off', 'GridAlpha', 0.15, ...
                    'Layer', 'top');
                ylim([0 ylimv(p,q)]); xlim([1.4 hmax+0.6]);
                if c == 1, ylabel(rowLab{q}, 'FontSize', fs); end
                if q == 3, xlabel('Harmonic order h', 'FontSize', fs); end
                src = 'Laboratory'; if c == 2, src = 'Simulation'; end
                title(sprintf('(%s) %s, %s', panel((q-1)*2+c), qty{q}, src), ...
                      'FontSize', fs+1, 'FontWeight', 'normal');
            end
        end
        
        % (measured lab GIC peaks in the labels)
        ax0 = axes('Position', [0.11 0.955 0.86 0.035], 'Visible', 'off', ...
                   'XLim', [0 1], 'YLim', [0 1]); hold(ax0, 'on');
        labs = {'No GIC', sprintf('Low (%.2f A)', gicLab(1)), ...
                sprintf('Moderate (%.2f A)', gicLab(2)), sprintf('High (%.2f A)', gicLab(3))};
        for k = 1:4
            x0 = 0.02 + (k-1)*0.25;
            patch(ax0, x0 + [0 0.035 0.035 0], [0.25 0.25 0.75 0.75], C(k,:), 'EdgeColor', 'none');
            text(ax0, x0 + 0.045, 0.5, labs{k}, 'FontName', fontName, 'FontSize', fs, ...
                 'VerticalAlignment', 'middle');
        end
        name = sprintf('harm_%sohm_phase%s', loads{L}, phases{p});
        save_fig(fig, fullfile(outDir, name));
        fprintf('Saved %s  (sim +GIC peaks: %.2f / %.2f / %.2f A)\n', name, gicSim);
        close(fig);
    end
end

% ---------- split figures: current only / voltage only (extra files) ----------
%  harm_current_<load>ohm_phase<X>  : I3, Lab | Sim                (1 x 2)
%  harm_voltage_<load>ohm_phase<X>  : V3 and V4, Lab | Sim         (2 x 2)
parts = {'current', 1, 7.5; 'voltage', [2 3], 14};      % name | rows (qty index) | height (cm)
for L = 1:numel(loads)
    gicLab = arrayfun(@(g) S(L,g).H.gic.lab, 1:3);
    labs = {'No GIC', sprintf('Low (%.2f A)', gicLab(1)), ...
            sprintf('Moderate (%.2f A)', gicLab(2)), sprintf('High (%.2f A)', gicLab(3))};
    for p = 1:3
        for pt = 1:size(parts,1)
            qs = parts{pt,2}; nr = numel(qs); H = parts{pt,3};
            fig = figure('Units','centimeters','Position',[2 2 figW H], 'Color','w');
            top = 1 - 1.6/H;                              % leave 1.6 cm for legend + title
            bot = 1.3/H;                                  % 1.3 cm for the x label
            gap = 1.9/H;                                  % between rows (tick labels + next title)
            axH = (top - bot - (nr-1)*gap)/nr;
            for r = 1:nr
                q = qs(r);
                for c = 1:2
                    s = {'lab','sim'}; s = s{c};
                    xl0 = [0.11 0.585];
                    ax = axes('Position', [xl0(c), top - r*axH - (r-1)*gap, 0.385, axH]);
                    Y = squeeze(D{L}.(s).(qty{q})(p, 2:hmax, :));
                    b = bar(2:hmax, Y, 0.85, 'grouped');
                    for k = 1:4, set(b(k), 'FaceColor', C(k,:), 'EdgeColor', 'none'); end
                    set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
                        'XTick', 2:hmax, 'YGrid', 'on', 'XGrid', 'off', 'GridAlpha', 0.15, 'Layer', 'top');
                    ylim([0 ylimv(p,q)]); xlim([1.4 hmax+0.6]);
                    if c == 1, ylabel(rowLab{q}, 'FontSize', fs); end
                    if r == nr, xlabel('Harmonic order h', 'FontSize', fs); end
                    src = 'Laboratory'; if c == 2, src = 'Simulation'; end
                    title(sprintf('(%s) %s, %s', panel((r-1)*2+c), qty{q}, src), ...
                          'FontSize', fs+1, 'FontWeight', 'normal');
                end
            end
            ax0 = axes('Position', [0.11 1 - 0.9/H, 0.86, 0.6/H], 'Visible', 'off', ...
                       'XLim', [0 1], 'YLim', [0 1]); hold(ax0, 'on');
            for k = 1:4
                x0 = 0.02 + (k-1)*0.25;
                patch(ax0, x0 + [0 0.035 0.035 0], [0.2 0.2 0.8 0.8], C(k,:), 'EdgeColor', 'none');
                text(ax0, x0 + 0.045, 0.5, labs{k}, 'FontName', fontName, 'FontSize', fs, ...
                     'VerticalAlignment', 'middle');
            end
            name = sprintf('harm_%s_%sohm_phase%s', parts{pt,1}, loads{L}, phases{p});
            save_fig(fig, fullfile(outDir, name));
            fprintf('Saved %s\n', name);
            close(fig);
        end
    end
end

% ---------- tables ----------
fid = fopen(fullfile(outDir, 'harmonic_table.csv'), 'w');
fprintf(fid, 'Loading_ohm,Source,Quantity,Phase,Condition,h1,h2,h3,h4,h5,h6,h7,Unit_h1,Unit_h2to7\n');
cond = [{'No GIC'}, levelNames];
for L = 1:numel(loads)
    for s = {'lab','sim'}
        for q = 1:3
            for p = 1:3
                for g = 1:4
                    if g == 1, raw = S(L,1).H.(s{1}).base.(qty{q})(p,:);
                    else,      raw = S(L,g-1).H.(s{1}).peak.(qty{q})(p,:); end
                    if q == 1, v = raw; u2 = 'A';
                    else,      v = [raw(1), 100*raw(2:end)/raw(1)]; u2 = '% of h1'; end
                    u1 = 'A'; if q > 1, u1 = 'V'; end
                    fprintf(fid, '%s,%s,%s,%s,%s,%s,%s,%s\n', loads{L}, s{1}, qty{q}, phases{p}, ...
                        cond{g}, strjoin(arrayfun(@(x) sprintf('%.4g', x), v, 'UniformOutput', false), ','), u1, u2);
                end
            end
        end
    end
end
fclose(fid);


fid = fopen(fullfile(outDir, 'harmonic_h1_table.tex'), 'w');
fprintf(fid, '%% Fundamental (h1) values, phase A. Requires \\usepackage{booktabs}.\n');
fprintf(fid, '\\begin{tabular}{llrrrrrr}\n\\toprule\n');
fprintf(fid, 'Load & Condition & \\multicolumn{2}{c}{$I_{3,1}$ (A)} & \\multicolumn{2}{c}{$V_{3,1}$ (V)} & \\multicolumn{2}{c}{$V_{4,1}$ (V)} \\\\\n');
fprintf(fid, ' & & Lab & Sim & Lab & Sim & Lab & Sim \\\\\n\\midrule\n');
for L = 1:numel(loads)
    for g = 1:4
        row = zeros(1,6); k = 0;
        for q = 1:3
            for s = {'lab','sim'}
                k = k + 1;
                if g == 1, row(k) = S(L,1).H.(s{1}).base.(qty{q})(1,1);
                else,      row(k) = S(L,g-1).H.(s{1}).peak.(qty{q})(1,1); end
            end
        end
        ld = ''; if g == 1, ld = sprintf('%s\\,$\\Omega$', loads{L}); end
        fprintf(fid, '%s & %s & %.3f & %.3f & %.1f & %.1f & %.1f & %.1f \\\\\n', ld, cond{g}, row);
    end
    if L < numel(loads), fprintf(fid, '\\midrule\n'); end
end
fprintf(fid, '\\bottomrule\n\\end{tabular}\n');
fclose(fid);
fprintf('\nTables: harmonic_table.csv, harmonic_h1_table.tex in %s\n', outDir);
