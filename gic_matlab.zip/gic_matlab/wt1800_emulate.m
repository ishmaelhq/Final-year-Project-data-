function R = wt1800_emulate(t, v, i, f0, Tblock, hmax)
%WT1800_EMULATE  Turn simulated waveforms into WT1800-style numeric records.
%
%   R = wt1800_emulate(t, v, i, 50, 0.5, 40)
%
%   
%   For each block (row) R holds:
%     tb          block centre time (s)
%     Urms, Irms  true RMS incl. DC         (WT1800 'Urms', 'Irms')
%     Uac,  Iac   RMS with DC removed       (WT1800 'Uac',  'Iac')
%     Udc,  Idc   block mean, SIGNED        (WT1800 'U(k)-DC' with min order 0)
%     Uh,   Ih    [nb x hmax] harmonic RMS, h = 1..hmax  (WT1800 'U(k)-n')
%     U1,   I1    complex RMS phasors of the fundamental (cosine reference)
%     P           active power = mean(v.*i)  (W)
%     Q1          fundamental reactive power = Im(U1*conj(I1)); + = inductive
%                 (lagging), the same sign convention as the WT1800 Q(k)-1
%     UthdF, IthdF  THD relative to h1 (%), using h2..hmax
%     UthdR, IthdR  THD relative to total RMS of h1..hmax (%)

    t = t(:); v = v(:); i = i(:);
    dt  = median(diff(t));
    N   = round(Tblock/dt);                    % samples per block
    cyc = Tblock*f0;                           % cycles per block
    if abs(cyc - round(cyc)) > 1e-9
        error('Tblock*f0 = %.4g must be an integer number of cycles.', cyc);
    end
    if abs(N*dt - Tblock) > 0.01*dt
        error('Tblock = %g s is not a whole number of samples (dt = %g s).', Tblock, dt);
    end
    if hmax*cyc >= N/2
        error('hmax = %d exceeds Nyquist for dt = %g s.', hmax, dt);
    end

    nb  = floor(numel(t)/N);
    bin = (1:hmax)*round(cyc) + 1;             % FFT bin of harmonic h
    R.tb = zeros(nb,1);
    [R.Urms, R.Irms, R.Uac, R.Iac, R.Udc, R.Idc, R.P, R.Q1] = deal(zeros(nb,1));
    R.Uh = zeros(nb,hmax); R.Ih = zeros(nb,hmax);
    R.U1 = complex(zeros(nb,1)); R.I1 = R.U1;

    for b = 1:nb
        k  = (b-1)*N + (1:N);
        vb = v(k); ib = i(k);
        R.tb(b)   = mean(t(k));
        R.Udc(b)  = mean(vb);              R.Idc(b)  = mean(ib);
        R.Urms(b) = sqrt(mean(vb.^2));     R.Irms(b) = sqrt(mean(ib.^2));
        R.Uac(b)  = sqrt(max(R.Urms(b)^2 - R.Udc(b)^2, 0));
        R.Iac(b)  = sqrt(max(R.Irms(b)^2 - R.Idc(b)^2, 0));
        R.P(b)    = mean(vb.*ib);

        V = fft(vb)/N;  I = fft(ib)/N;
        Vph = sqrt(2)*V(bin);  Iph = sqrt(2)*I(bin);   % RMS phasors
        R.Uh(b,:) = abs(Vph);  R.Ih(b,:) = abs(Iph);
        R.U1(b) = Vph(1);      R.I1(b) = Iph(1);
        R.Q1(b) = imag(Vph(1)*conj(Iph(1)));
    end

    R.UthdF = 100*sqrt(sum(R.Uh(:,2:end).^2,2)) ./ R.Uh(:,1);
    R.IthdF = 100*sqrt(sum(R.Ih(:,2:end).^2,2)) ./ R.Ih(:,1);
    R.UthdR = 100*sqrt(sum(R.Uh(:,2:end).^2,2)) ./ sqrt(sum(R.Uh.^2,2));
    R.IthdR = 100*sqrt(sum(R.Ih(:,2:end).^2,2)) ./ sqrt(sum(R.Ih.^2,2));
end
