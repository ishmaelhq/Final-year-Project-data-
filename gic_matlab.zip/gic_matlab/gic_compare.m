function out = gic_compare(cfg)
%GIC_COMPARE  PSCAD vs WT1800 lab data for ONE run (one loading, one GIC level).
%
%   out = gic_compare(cfg)      - normally called by run_all.m
%
%  
%Reads the PSCAD Legacy output (.inf + .out files) and the WT1800 CSV.
%Emulates the WT1800 on the simulated waveforms: 0.5 s blocks, harmonics by
%synchronous FFT (25 cycles per block, rectangular window), Q1, RMS, THD.
%Puts both data sets on the same basis (same |GIC| definition, same THD
%definition, same harmonic orders) and compares them against |GIC|.
%Prints a baseline / peak table (sim vs lab, % error) and saves it as CSV.
%Wavelet (MODWT db4 + CWT) on the simulated waveforms - the lab has none.
%
%   Outputs in cfg.outDir: comparison_table.csv, fig1..fig4 PNGs, results.mat
%   out: struct with Ms (sim metrics), Ml (lab metrics), T (table), cfg

if ~exist(cfg.outDir, 'dir'), mkdir(cfg.outDir); end

fprintf('\n================ %s ================\n', cfg.label);

%% 1. Read
S = read_pscad_out(cfg.simInf);
L = read_wt1800_csv(cfg.labCsv);

%% 2-3. Same-basis metrics
[Ms, Rs, sig] = summarise_sim(S, cfg);
Ml = summarise_lab(L, cfg);

%% 4. Table
T = compare_table(Ms, Ml, cfg, fullfile(cfg.outDir, 'comparison_table.csv'));

%% Figure 1 - lab vs sim against |GIC|
pos = Ms.Igic >= 0;
cS1 = [0.13 0.40 0.67]; cS2 = [0.80 0.30 0.15]; cL = [0.35 0.35 0.35];
plt = {'I3_h2','I3 h2 (% of h1)'; 'I3_thd','I3 THD-F h2-h8 (%)'; 'Q1','Q1 3-ph, T2 primary (var)'; ...
       'V4_h3','V4 h3 (% of h1)'; 'V4_thd','V4 THD-F h2-h8 (%)'; 'V4rms','V4 RMS (V)'};
vis = 'off'; if cfg.showFigs, vis = 'on'; end
f1 = figure('Name','Lab vs sim','Position',[60 60 1250 650],'Visible',vis);
for k = 1:size(plt,1)
    subplot(2,3,k); hold on; grid on; box on;
    plot(Ml.Igic_abs, Ml.(plt{k,1}), 'o', 'Color', cL, 'MarkerSize', 4);
    plot(Ms.Igic_abs(pos),  Ms.(plt{k,1})(pos),  '.', 'Color', cS1, 'MarkerSize', 9);
    plot(Ms.Igic_abs(~pos), Ms.(plt{k,1})(~pos), '.', 'Color', cS2, 'MarkerSize', 9);
    xlabel('|I_{GIC}| total (A)'); ylabel(plt{k,2});
    if k == 1, legend('Lab (WT1800)','Sim, +GIC','Sim, -GIC','Location','northwest'); end
end
sgtitle_compat(f1, ['Lab vs PSCAD - ' cfg.label]);
print(f1, fullfile(cfg.outDir, 'fig1_lab_vs_sim.png'), '-dpng', '-r150');

%% Figure 2 - simulated time series (signed GIC shows polarity effects)
f2 = figure('Name','Sim time series','Position',[80 80 900 700],'Visible',vis);
tt = Ms.t - Ms.t(1);
subplot(4,1,1); plot(sig.t - sig.t(1), sig.Igic, 'k'); grid on; ylabel('I_{GIC} (A)');
title(['PSCAD time series - ' cfg.label]);
subplot(4,1,2); plot(tt, Ms.Q1, '.-', 'Color', cS1); grid on; ylabel('Q1 (var)');
subplot(4,1,3); plot(tt, [Ms.I3_h2 Ms.I3_h3 Ms.I3_h4], '.-'); grid on;
ylabel('I3 (% h1)'); legend('h2','h3','h4','Location','best');
subplot(4,1,4); plot(tt, Ms.V4rms, '.-', 'Color', cS2); grid on;
ylabel('V4 RMS (V)'); xlabel('Time from start of window (s)');
print(f2, fullfile(cfg.outDir, 'fig2_sim_timeseries.png'), '-dpng', '-r150');

%% 5. Wavelet - simulated I3 (phase A) and V4 (phase A)
W3 = wavelet_bands(sig.I3(:,1), sig.fs, cfg.f0, cfg.Tblock);
W4 = wavelet_bands(sig.V4(:,1), sig.fs, cfg.f0, cfg.Tblock);
if ~isempty(W3)
    f3 = figure('Name','Wavelet','Position',[100 100 1100 750],'Visible',vis);
    nb = min(size(W3.rms,1), numel(Ms.Igic));
    show = W3.L-3:W3.L+1;                         % harmonic-relevant bands + DC
    subplot(3,1,1);
    plot(W3.tb(1:nb), W3.rms(1:nb, show), 'LineWidth', 1.2); grid on;
    lg = cell(1, numel(show));
    for j = 1:numel(show)
        lg{j} = sprintf('%s %.0f-%.0f Hz', W3.label{show(j)}, W3.f(show(j),1), W3.f(show(j),2));
    end
    legend(lg, 'Location', 'eastoutside'); ylabel('I3a band RMS (A)');
    title(['Wavelet band energy, T2 primary current (sim) - ' W3.method]);
    subplot(3,1,2);
    plot(W4.tb(1:nb), W4.rms(1:nb, show), 'LineWidth', 1.2); grid on;
    legend(lg, 'Location', 'eastoutside'); ylabel('V4a band RMS (V)');
    subplot(3,1,3);
    plot(W3.tb(1:nb), Ms.Igic(1:nb), 'k', 'LineWidth', 1.2); grid on;
    ylabel('I_{GIC} (A)'); xlabel('Time from start of window (s)');
    print(f3, fullfile(cfg.outDir, 'fig3_wavelet_bands.png'), '-dpng', '-r150');

    % CWT scalograms: 0.2 s of I3a at +peak and -peak GIC
    if true
        f4 = figure('Name','CWT','Position',[120 120 1100 450],'Visible',vis);
        [~, ip] = max(sig.Igic);  [~, in] = min(sig.Igic);
        idx = {ip, in}; ttl = {'+peak GIC', '-peak GIC'};
        n2 = round(0.1*sig.fs);
        for s = 1:2
            k = max(1, idx{s}-n2) : min(numel(sig.Igic), idx{s}+n2);
            if exist('cwt', 'file')
                [wt, fr] = cwt(sig.I3(k,1), sig.fs);
            else
                [wt, fr] = cwt_morlet_basic(sig.I3(k,1), sig.fs, 10, 500, 80);
            end
            [fr, o] = sort(fr(:));  wt = wt(o,:);      % ascending frequency for imagesc
            subplot(1,2,s);
            pcolor((k - k(1))/sig.fs*1e3, fr, abs(wt)); shading flat;   % pcolor handles log-spaced frequencies
            xlim([0 (numel(k)-1)/sig.fs*1e3]); ylim([10 500]); xlabel('ms'); ylabel('Hz'); colorbar;
            title(['I3a CWT, ' ttl{s}]);
        end
        print(f4, fullfile(cfg.outDir, 'fig4_cwt.png'), '-dpng', '-r150');
    end
end

%% Save everything for the report
save(fullfile(cfg.outDir, 'results.mat'), 'cfg', 'Ms', 'Ml', 'T', 'Rs');
fprintf('\nSaved to %s\n', cfg.outDir);
if ~cfg.showFigs, close all; end
out.Ms = Ms; out.Ml = Ml; out.T = T; out.cfg = cfg;
end
