function L = read_wt1800_csv(csvFile)
%READ_WT1800_CSV  Read a Yokogawa WT1800 stored-numeric CSV file.
%
%   L = read_wt1800_csv('High_GIC.CSV')
%
%   L.names {1 x C}  column headers exactly as written by the WT1800,
%                    e.g. 'Urms-1', 'U(k)-4-3', 'Q(k)-1-1', 'Ithd-2'
%   L.data  [N x C]  numeric values ('NAN' and text columns become NaN)
%   L.t     [N x 1]  time from the first record (s)
%
%   lab_col(L,'U(k)-4-3') to pull a column by its WT1800 name.

    fid = fopen(csvFile, 'r');
    if fid < 0, error('Cannot open %s', csvFile); end
    hdr   = fgetl(fid);
    names = strtrim(regexp(hdr, ',', 'split'));
    C = textscan(fid, repmat('%s', 1, numel(names)), 'Delimiter', ',');
    fclose(fid);

    n = min(cellfun(@numel, C));
    data = nan(n, numel(names));
    for j = 1:numel(names)
        data(:,j) = str2double(C{j}(1:n));      % ' 133.77 ' -> 133.77, 'NAN' -> NaN
    end
    L.names = names; L.data = data;

    % ---- time vector ----
    jT  = find(strcmp(names, 'Time'), 1);
    jMs = find(strcmp(names, 'Millisecond'), 1);
    tod = nan(n,1);
    if ~isempty(jT)
        for r = 1:n
            hms = sscanf(C{jT}{r}, '%d:%d:%d');
            if numel(hms) == 3, tod(r) = hms(1)*3600 + hms(2)*60 + hms(3); end
        end
    end
    if ~isempty(jMs) && ~all(isnan(tod))
        tod = tod + data(:,jMs)/1000;
        L.t = tod - tod(1);
    elseif ~all(isnan(tod))
        % no milliseconds column: spread the records evenly over the logged span
        span = (tod(end) - tod(1)) + 1;
        L.t  = (0:n-1)' * span / n;
    else
        L.t = (0:n-1)';
    end
    fprintf('WT1800: %d records, %d columns, %.1f s, mean interval %.3f s\n', ...
        n, numel(names), L.t(end), mean(diff(L.t)));
end
