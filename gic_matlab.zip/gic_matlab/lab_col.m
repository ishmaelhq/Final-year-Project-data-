function x = lab_col(L, name)
%LAB_COL  Return a WT1800 column by its exact header name, e.g. 'U(k)-4-3'.
%   Returns NaN(N,1) with a warning if the column was not stored.
    j = find(strcmp(L.names, name), 1);
    if isempty(j)
        warning('lab_col:missing', 'Column "%s" not in the WT1800 file.', name);
        x = nan(size(L.data,1), 1);
    else
        x = L.data(:, j);
    end
end
