function [wt, f] = cwt_morlet_basic(x, fs, fmin, fmax, nf)
%CWT_MORLET_BASIC  Continuous wavelet transform (analytic Morlet), no toolbox.
%
%   [wt, f] = cwt_morlet_basic(x, fs, 10, 500, 80)
%     wt : [nf x N] complex coefficients (use abs(wt) for the scalogram)
%     f  : [nf x 1] centre frequencies (Hz), ascending, log-spaced
%
%   Morlet with w0 = 6 (good time-frequency balance), computed via FFT.
%   L1 normalisation, so a sinusoid of amplitude A shows |wt| ~ A/2... A
%   at its own frequency regardless of scale - fine for comparing bands.

    if nargin < 3, fmin = 10;  end
    if nargin < 4, fmax = 500; end
    if nargin < 5, nf   = 80;  end
    x  = x(:)'; N = numel(x);
    w0 = 6;
    f  = logspace(log10(fmin), log10(fmax), nf)';
    X  = fft(x - mean(x));
    w  = 2*pi*fs*[0:floor(N/2), -(ceil(N/2)-1):-1]/N;     % rad/s for each FFT bin
    wt = complex(zeros(nf, N));
    for k = 1:nf
        s = w0/(2*pi*f(k));                                % scale (s) for this frequency
        psi = 2*exp(-0.5*(s*w - w0).^2) .* (w > 0);        % analytic Morlet, L1-normalised
        wt(k,:) = ifft(X .* psi);
    end
end
