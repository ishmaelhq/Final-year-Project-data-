function save_fig(fig, base)
%SAVE_FIG  Save a figure as vector PDF (for LaTeX) and 300-dpi PNG (for previews).
    if exist('exportgraphics', 'file')              
        exportgraphics(fig, [base '.pdf'], 'ContentType', 'vector');
        exportgraphics(fig, [base '.png'], 'Resolution', 300);
    else
        set(fig, 'PaperUnits', 'centimeters');
        pos = get(fig, 'Position');
        set(fig, 'PaperSize', pos(3:4), 'PaperPosition', [0 0 pos(3:4)]);
        print(fig, [base '.pdf'], '-dpdf');
        print(fig, [base '.png'], '-dpng', '-r300');
    end
end
