%% PLOT_Q1_VS_GIC  Reactive power demand vs peak GIC, laboratory vs simulation.
%
%  Reads results_summary\all_runs_summary.csv (written by run_all.m), so no
%  re-processing is needed.
%
%  Two panels: (a) 50 ohm, (b) 100 ohm, same y-axis.
%    Laboratory  = solid line, filled circles
%    Simulation  = dashed line, open squares
%  x = peak |I_GIC| of each source (measured for the lab, simulated for PSCAD);
%  the 0 A point is the no-GIC baseline (from the Low run).
%  Q1 = fundamental reactive power at the T2 primary, three-phase total.
%
%  Outputs in results_figures\ :  q1_vs_gic.pdf/.png, q1_table.tex

clear; close all; clc;

%% ===================== settings =====================
csvFile = fullfile(pwd, 'results_summary', 'all_runs_summary.csv');
outDir  = fullfile(pwd, 'results_figures');
figW = 16; figH = 7;                       % cm
fontName = 'Helvetica'; fs = 8;
cLab = [0.051 0.212 0.420];                % #0d366b  dark blue
cSim = [0.922 0.408 0.204];                % #eb6834  orange
%% ====================================================

if ~exist(outDir, 'dir'), mkdir(outDir); end
D = read_summary(csvFile);
loads  = {'50 ohm', '100 ohm'};
levels = {'Low', 'Moderate', 'High'};

% ---------- collect: rows = No GIC, Low, Moderate, High ----------
X = struct(); Q = struct();
for L = 1:2
    xl = zeros(4,1); xs = xl; ql = xl; qs = xl;
    for g = 1:3
        G = pick(D, loads{L}, levels{g}, 'Igic_abs');
        M = pick(D, loads{L}, levels{g}, 'Q1');
        xl(g+1) = G(4); xs(g+1) = G(5);              % peak |I_GIC|
        ql(g+1) = M(4); qs(g+1) = M(5);              % Q1 at peak
        if g == 1, ql(1) = M(1); qs(1) = M(2); end   % no-GIC baseline (x = 0)
    end
    X(L).lab = xl; X(L).sim = xs; Q(L).lab = ql; Q(L).sim = qs;
end
ymax = 50*ceil(1.08*max([Q(1).lab; Q(1).sim; Q(2).lab; Q(2).sim])/50);   % next 50 var above the data
xmax = 1.8;

% ---------- figure ----------
fig = figure('Units', 'centimeters', 'Position', [2 2 figW figH], 'Color', 'w');
ttl = {'(a) 50 \Omega load', '(b) 100 \Omega load'};
for L = 1:2
    ax = axes('Position', [0.09 + (L-1)*0.47, 0.17, 0.40, 0.65]); hold(ax, 'on');
    plot(ax, X(L).lab, Q(L).lab, '-o', 'Color', cLab, 'LineWidth', 1.2, ...
         'MarkerFaceColor', cLab, 'MarkerEdgeColor', cLab, 'MarkerSize', 5);
    plot(ax, X(L).sim, Q(L).sim, '--s', 'Color', cSim, 'LineWidth', 1.2, ...
         'MarkerFaceColor', 'w', 'MarkerEdgeColor', cSim, 'MarkerSize', 5.5);
    set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
        'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.15, 'Layer', 'top', ...
        'XLim', [0 xmax], 'YLim', [0 ymax], 'XTick', 0:0.5:xmax);
    xlabel(ax, 'Peak |I_{GIC}| (A)', 'FontSize', fs);
    if L == 1, ylabel(ax, 'Q_1 (var)', 'FontSize', fs); end
    title(ax, ttl{L}, 'FontSize', fs+1, 'FontWeight', 'normal');
end
% legend strip on top
ax0 = axes('Position', [0.09 0.9 0.87 0.08], 'Visible', 'off', 'XLim', [0 1], 'YLim', [0 1]); hold(ax0, 'on');
plot(ax0, [0.30 0.36], [0.5 0.5], '-',  'Color', cLab, 'LineWidth', 1.2);
plot(ax0, 0.33, 0.5, 'o', 'MarkerFaceColor', cLab, 'MarkerEdgeColor', cLab, 'MarkerSize', 5);
text(ax0, 0.375, 0.5, 'Laboratory', 'FontName', fontName, 'FontSize', fs, 'VerticalAlignment', 'middle');
plot(ax0, [0.55 0.61], [0.5 0.5], '--', 'Color', cSim, 'LineWidth', 1.2);
plot(ax0, 0.58, 0.5, 's', 'MarkerFaceColor', 'w', 'MarkerEdgeColor', cSim, 'MarkerSize', 5.5);
text(ax0, 0.625, 0.5, 'Simulation', 'FontName', fontName, 'FontSize', fs, 'VerticalAlignment', 'middle');
save_fig(fig, fullfile(outDir, 'q1_vs_gic'));

% ---------- table (console + LaTeX) ----------
cond = {'No GIC', 'Low', 'Moderate', 'High'};
fid = fopen(fullfile(outDir, 'q1_table.tex'), 'w');
fprintf(fid, '%% Requires \\usepackage{booktabs}\n\\begin{tabular}{llrrrrr}\n\\toprule\n');
fprintf(fid, 'Load & Condition & \\multicolumn{2}{c}{Peak $|I_{GIC}|$ (A)} & \\multicolumn{2}{c}{$Q_1$ (var)} & Error (\\%%) \\\\\n');
fprintf(fid, ' & & Lab & Sim & Lab & Sim & \\\\\n\\midrule\n');
fprintf('\n%-8s %-9s | %7s %7s | %8s %8s %7s | %8s %8s %7s\n', 'Load', 'Cond', 'GIC lab', 'GIC sim', ...
        'Q1 lab', 'Q1 sim', 'err %', 'dQ1 lab', 'dQ1 sim', 'err %');
for L = 1:2
    for g = 1:4
        ql = Q(L).lab(g); qs = Q(L).sim(g);
        e  = 100*(qs - ql)/ql;
        if g == 1, dl = NaN; ds = NaN; ed = NaN;            % rise above no-GIC
        else, dl = ql - Q(L).lab(1); ds = qs - Q(L).sim(1); ed = 100*(ds - dl)/dl; end
        fprintf('%-8s %-9s | %7.2f %7.2f | %8.1f %8.1f %+7.1f | %8.1f %8.1f %+7.1f\n', ...
                loads{L}, cond{g}, X(L).lab(g), X(L).sim(g), ql, qs, e, dl, ds, ed);
        ld = ''; if g == 1, ld = sprintf('%s\\,$\\Omega$', strtok(loads{L})); end
        fprintf(fid, '%s & %s & %.2f & %.2f & %.1f & %.1f & %+.1f \\\\\n', ld, cond{g}, ...
                X(L).lab(g), X(L).sim(g), ql, qs, e);
    end
    if L == 1, fprintf(fid, '\\midrule\n'); end
end
fprintf(fid, '\\bottomrule\n\\end{tabular}\n'); fclose(fid);
fprintf('\nSaved q1_vs_gic.pdf/.png and q1_table.tex in %s\n', outDir);

% ======================================================================
function D = read_summary(f)
% all_runs_summary.csv: the run name contains a comma, so read each row from
% the right: ..., Loading, Level, Metric, Unit, 9 numbers.
    fidr = fopen(f, 'r'); if fidr < 0, error('Cannot open %s', f); end
    fgetl(fidr);                                   % header
    D = struct('load', {}, 'level', {}, 'metric', {}, 'v', {});
    while true
        s = fgetl(fidr); if ~ischar(s), break; end
        c = strtrim(regexp(s, ',', 'split'));
        if numel(c) < 14, continue; end
        D(end+1).load = c{end-12}; D(end).level = c{end-11};   %#ok<AGROW>
        D(end).metric = c{end-10}; D(end).v = str2double(c(end-8:end));
    end
    fclose(fidr);
end

function v = pick(D, ld, lv, m)
    k = find(strcmp({D.load}, ld) & strcmp({D.level}, lv) & strcmp({D.metric}, m), 1);
    if isempty(k), error('Row not found: %s / %s / %s', ld, lv, m); end
    v = D(k).v;    % [Lab_base Sim_base Err Lab_peak Sim_peak Err Lab_chg Sim_chg Err]
end
