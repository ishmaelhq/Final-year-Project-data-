%% WAVELET_ANALYSIS  What the wavelet transform shows that the FFT does not.
%
%  Needs the Wavelet Toolbox (modwt, modwtmra, cwt).
%
%  PART 1 - PSCAD waveforms 
%    Signal: T2 magnetising current i_m = I3a - V4a/R_load (T2 is 1:1 and the
%    load is resistive), so the load current does not mask the saturation.
%    MODWT multiresolution analysis, sym8, 6 levels. i_m is resampled to
%    fs = 50*2^6.5 = 4525.5 Hz so each band is centred on a harmonic group:
%       A6  0-35 Hz  DC (GIC)      D6  35-71 Hz   fundamental
%       D5  71-141   h2            D4  141-283    h3-h5      D3 283-566  h6-h11
%   
%
%  PART 2 - laboratory vs simulation, same wavelet (sym8, 4 levels)
%    Applied to the 0.5 s record series (|I_GIC|, I3 h2, V4 RMS, Q1) from the
%    results_Gic_* folders made by run_all.m.
%       
%
%  Outputs in results_wavelet\ :
%    wav_mra_<run>.pdf/.png      Fig 1: MRA bands at +peak, zero and -peak GIC
%    wav_cycle_metrics.pdf/.png  Fig 2: per-cycle metrics vs GIC, all runs
%    wav_cwt_<run>.pdf/.png      Fig 3: CWT scalograms
%    wav_lab_vs_sim.pdf/.png     Fig 4: record series, trend + fluctuation
%    wav_part1.csv, wav_part2.csv, wav_part2.tex

clear; close all; clc;

%% ===================== settings =====================
simDir  = 'C:\Users\Student\Downloads\GIC analysis\GIC_Investigation.gf81_x86';  % .inf/.out
resRoot = 'C:\Users\Student\Downloads\GIC analysis\gic_matlab';                          % folder holding the results_Gic_* folders
runs    = {'Gic_Low_50','Gic_Mod_50','Gic_High_50','Gic_Low_100','Gic_Mod_100','Gic_High_100'};
loadOf  = [50 50 50 100 100 100];
figRun  = 'Gic_High_50';                % run used for Figs 1 and 3
wname   = 'sym8';
J       = 6;                            % MODWT levels, waveforms
J2      = 4;                            % MODWT levels, 0.5 s record series
fsw     = 50*2^6.5;                     % 4525.48 Hz (band centring, see header)
fsc     = 1000;                         % Hz, CWT sampling rate (memory)
fontName = 'Helvetica'; fs = 8;
cLd  = [0.165 0.471 0.839; 0.922 0.408 0.204];   % 50 ohm blue, 100 ohm orange
cLab = [0.051 0.212 0.420]; cSim = [0.922 0.408 0.204];
%% ====================================================

if isempty(which('modwtmra')) || isempty(which('cwt'))
    error('Wavelet Toolbox not found (modwt / modwtmra / cwt).');
end
cfg = gic_defaults();
outDir = fullfile(pwd, 'results_wavelet'); if ~exist(outDir, 'dir'), mkdir(outDir); end
bandName = {'D1','D2','D3','D4','D5','D6','A6'};

%% ======================= PART 1 =======================
C = struct([]);
for r = 1:numel(runs)
    fIn = fullfile(simDir, [runs{r} '.inf']);                 % read_pscad_out also takes .infx
    if ~exist(fIn, 'file') && ~exist([fIn 'x'], 'file')
        warning('Skipping %s (.inf / .infx not found)', fIn); continue;
    end
    S  = read_pscad_out(fIn);
    k  = S.t >= cfg.t_win(1) & S.t < cfg.t_win(2);
    t  = S.t(k);
    jG = find_phase_channels(S.names, cfg.ch.Igic, 1);
    jV = find_phase_channels(S.names, cfg.ch.V3, 3);
    jI = find_phase_channels(S.names, cfg.ch.I3, 3);
    j4 = find_phase_channels(S.names, cfg.ch.V4, 3);
    ig = cfg.Iscale*S.data(k, jG);  i3 = cfg.Iscale*S.data(k, jI(1));
    v3 = cfg.Vscale*S.data(k, jV(1)); v4 = cfg.Vscale*S.data(k, j4(1));
    im = i3 - v4/loadOf(r);            % T2 magnetising current (1:1 ratio, resistive load)
    fs0 = 1/median(diff(t));
    clear S

    % ---- resample to fsw and decompose ----
    tw = (t(1):1/fsw:t(end))';
    x  = interp1(t, im, tw, 'spline');
    v  = interp1(t, v3, tw, 'spline');
    g  = interp1(t, ig, tw, 'linear');
    mra = modwtmra(modwt(x', wname, J), wname);            % (J+1) x N, rows sum to x
    d   = sum(mra(1:5,:), 1)';                             % distortion: all bands above the fundamental
    fprintf('%s: fs %.0f -> %.1f Hz, %d samples, MRA reconstruction error %.2e A\n', ...
            runs{r}, fs0, fsw, numel(x), max(abs(sum(mra,1)' - x)));

    % ---- per-cycle metrics ----
    z  = find(v(1:end-1) < 0 & v(2:end) >= 0);              % V3a positive zero crossings
    nc = numel(z) - 1;
    M  = struct('t', zeros(nc,1), 'Ig', zeros(nc,1), 'D5', zeros(nc,1), 'D4', zeros(nc,1), 'AI', zeros(nc,1), ...
                'fw', nan(nc,1), 'th', nan(nc,1));
    for c = 1:nc
        n  = z(c)+1 : z(c+1);
        th = 360*(0:numel(n)-1)'/numel(n);
        M.Ig(c) = mean(g(n)); M.t(c) = tw(n(1));
        M.D5(c) = sqrt(mean(mra(5,n).^2));
        M.D4(c) = sqrt(mean(mra(4,n).^2));
        dc = d(n);  pos = th >= 90 & th < 270;
        Ep = sum(dc(pos).^2); En = sum(dc(~pos).^2);
        M.AI(c) = (Ep - En)/(Ep + En);
        if abs(M.AI(c)) > 0.5                                % one dominant pulse per cycle
            p = sign(M.AI(c))*dc;
            sh = 0;                                      % -GIC pulse sits at 0/360 deg:
            if M.AI(c) < 0, sh = round(numel(p)/2); p = circshift(p, sh); end   % centre it
            [pk, ip] = max(p);
            a = ip; while a > 1 && p(a-1) > pk/2, a = a - 1; end
            b = ip; while b < numel(p) && p(b+1) > pk/2, b = b + 1; end
            dt = 360/numel(n); h = pk/2;                 % half-max crossings, linearly interpolated
            ta = th(a); if a > 1,        ta = th(a) - dt*(p(a) - h)/(p(a) - p(a-1)); end
            tb = th(b); if b < numel(p), tb = th(b) + dt*(p(b) - h)/(p(b) - p(b+1)); end
            M.fw(c) = tb - ta;
            M.th(c) = mod(th(ip) - 360*sh/numel(p), 360);
        end
    end
    M.rise = gradient(M.Ig) > 0;
    M.run = runs{r}; M.load = loadOf(r);
    if isempty(C), C = M; else, C(end+1) = M; end          %#ok<SAGROW>

    % ---- Fig 1: MRA bands, 3 cycles at +peak, zero crossing, -peak GIC ----
    if strcmp(runs{r}, figRun)
        nsm = round(fsw); gs = conv(g, ones(nsm,1)/nsm, 'same');   % 1 s smoothing for the GIC instants
        [~, ip] = max(gs); [~, in] = min(gs);
        iz = find(gs(1:end-1) < 0 & gs(2:end) >= 0, 1);
        if isempty(iz), [~, iz] = min(abs(gs)); end
        inst = [ip iz in];
        ttl  = {sprintf('+peak GIC (%.2f A)', g(ip)), 'GIC zero crossing', sprintf('-peak GIC (%.2f A)', g(in))};
        rows = {x, mra(6,:)', mra(5,:)', mra(4,:)'};
        rlab = {'i_{m,a} (A)', 'D6, 35-71 Hz (A)', 'D5, 71-141 Hz (A)', 'D4, 141-283 Hz (A)'};
        f1 = figure('Units','centimeters','Position',[2 2 16 15],'Color','w');
        for q = 1:4
            yl = 0;
            for s = 1:3
                c0 = find(z >= inst(s), 1); if isempty(c0) || c0+3 > numel(z), c0 = numel(z)-3; end
                n  = z(c0)+1 : z(c0+3);
                yl = max(yl, max(abs(rows{q}(n))));
            end
            yl = 1.1*yl;
            for s = 1:3
                c0 = find(z >= inst(s), 1); if isempty(c0) || c0+3 > numel(z), c0 = numel(z)-3; end
                n  = z(c0)+1 : z(c0+3);
                tm = (n - n(1))/fsw*1e3;
                ax = axes('Position', [0.10 + (s-1)*0.30, 0.76 - (q-1)*0.215, 0.26, 0.17]); hold(ax, 'on');
                for cc = 0:2                                   % positive-flux half-cycles (90-270 deg)
                    patch(ax, 20*cc + [5 15 15 5], yl*[-1 -1 1 1], [0.93 0.93 0.93], 'EdgeColor', 'none');
                end
                plot(ax, tm, rows{q}(n), 'Color', cLab, 'LineWidth', 0.9);
                set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
                    'XLim', [0 60], 'YLim', [-yl yl], 'XTick', 0:10:60, 'Layer', 'top');
                if s == 1, ylabel(ax, rlab{q}); else, set(ax, 'YTickLabel', []); end
                if q == 4, xlabel(ax, 'Time (ms)'); else, set(ax, 'XTickLabel', []); end
                if q == 1, title(ax, ttl{s}, 'FontWeight', 'normal', 'FontSize', fs+1); end
            end
        end
        annotation(f1, 'textbox', [0.10 0.005 0.86 0.03], 'String', ...
            'Shaded: positive-flux half-cycles (90-270 deg of V_{3a}).', 'EdgeColor', 'none', ...
            'FontName', fontName, 'FontSize', fs-1);
        save_fig(f1, fullfile(outDir, ['wav_mra_' runs{r}]));

        % ---- Fig 3: CWT scalograms over one GIC period ----
        tc = (t(1):1/fsc:t(end))';
        xc = {interp1(t, im, tc, 'spline'), interp1(t, v4, tc, 'spline')};
        f3 = figure('Units','centimeters','Position',[2 2 16 13],'Color','w');
        ax = axes('Position', [0.10 0.80 0.70 0.14]);
        plot(ax, tc - tc(1), interp1(t, ig, tc), 'k', 'LineWidth', 1);
        set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
            'XLim', [0 tc(end)-tc(1)], 'XTickLabel', [], 'YGrid', 'on');
        ylabel(ax, 'I_{GIC} (A)'); title(ax, ['CWT (analytic Morlet), ' strrep(runs{r}, '_', ' ')], ...
            'FontWeight', 'normal', 'FontSize', fs+1);
        lab3 = {'i_{m,a}', 'V_{4a}'};
        for s = 1:2
            [wt, fr] = cwt(xc{s}, 'amor', fsc, 'VoicesPerOctave', 16, 'FrequencyLimits', [20 400]);
            % RMS of |W| over each 20 ms cycle. (Taking every 20th sample instead
            % would strobe: always the same instant in the cycle, either on or
            % between the saturation pulses, depending on GIC polarity.)
            dk = round(fsc/cfg.f0); nb = floor(size(wt,2)/dk);
            W2 = reshape(abs(wt(:, 1:nb*dk)).^2, size(wt,1), dk, nb);
            Wc = sqrt(squeeze(mean(W2, 2)));                 % [nf x nb]
            A  = 20*log10(Wc / max(Wc(:)));
            tb = (0:nb-1)'*dk/fsc + 0.5/cfg.f0;              % cycle centres (s)
            ax = axes('Position', [0.10 0.44 - (s-1)*0.34, 0.70, 0.31]);
            % surface with Z = dB value, viewed from above: a data tip now shows the
            % magnitude (pcolor puts every point at Z = 0)
            surf(ax, tb, fr, A, 'EdgeColor', 'none'); view(ax, 2);
            set(ax, 'YScale', 'log', 'YTick', 50*(1:8), 'FontName', fontName, 'FontSize', fs, ...
                'TickDir', 'out', 'XLim', [0 tc(end)-tc(1)], 'YLim', [20 400], 'Layer', 'top');
            caxis(ax, [-60 0]);
            ylabel(ax, [lab3{s} ' frequency (Hz)']);
            if s == 2, xlabel(ax, 'Time from start of window (s)'); else, set(ax, 'XTickLabel', []); end
            cb = colorbar(ax); set(cb, 'Position', [0.82 0.10 + (2-s)*0.34, 0.02, 0.31]);
            set(ax, 'Position', [0.10 0.44 - (s-1)*0.34, 0.70, 0.31]);
            ylabel(cb, 'Wavelet magnitude (dB, 0 = max)', 'FontSize', fs);
            clear wt W2
        end
        save_fig(f3, fullfile(outDir, ['wav_cwt_' runs{r}]));
    end
end

if isempty(C)
    error(['Part 1: no PSCAD runs found in\n   %s\nSet simDir (line 41) to the folder ' ...
           'holding Gic_*.inf (or .infx) and the Gic_*_01.out files.'], simDir);
end

% ---- Part 1 summary ----
%  Polarity switch: the core changes which half-cycle saturates when the
%  smoothed AI crosses zero. Delay = (time of AI zero crossing) - (time of the
%  GIC zero crossing), for the falling and the rising GIC reversal.
%    both delays > 0, equal      -> the core lags the GIC (dynamic lag)
%    delays opposite in sign      -> a DC offset: the core's "zero" is not at I_GIC = 0
%  I_sw = GIC at which the switch happens on each branch.
fid = fopen(fullfile(outDir, 'wav_part1.csv'), 'w');
fprintf(fid, ['Run,Peak_GIC_A,D5_at_+peak_A,D5_at_-peak_A,AI_at_+peak,AI_at_-peak,' ...
              'Isw_falling_A,Isw_rising_A,Delay_falling_s,Delay_rising_s,' ...
              'Pulse_width_deg,Pulse_angle_+GIC_deg,Pulse_angle_-GIC_deg\n']);
fprintf('\n%-13s %6s %7s %7s %6s %6s | %7s %7s %7s %7s | %6s %6s %6s\n', 'Run', 'GICpk', ...
        'D5 +pk', 'D5 -pk', 'AI+', 'AI-', 'Isw f', 'Isw r', 'dly f', 'dly r', 'width', 'ang+', 'ang-');
for r = 1:numel(C)
    M = C(r); a = abs(M.Ig); gp = max(a);
    pk = a >= 0.9*gp; pp = pk & M.Ig > 0; pn = pk & M.Ig < 0;
    ns = 25;                                                 % 0.5 s smoothing (25 cycles)
    As = conv(M.AI, ones(ns,1)/ns, 'same');
    Gs = conv(M.Ig, ones(ns,1)/ns, 'same');
    zA = find(sign(As(1:end-1)) ~= sign(As(2:end)));         % AI zero crossings
    zG = find(sign(Gs(1:end-1)) ~= sign(Gs(2:end)));         % GIC zero crossings
    zA = zA(zA > ns & zA < numel(As) - ns); zG = zG(zG > ns & zG < numel(Gs) - ns);
    sw = nan(1,4);                                           % [Isw_f Isw_r delay_f delay_r]
    for k = 1:numel(zG)
        fall = Gs(zG(k)) > Gs(zG(k)+1);
        if isempty(zA), break; end
        [~, j] = min(abs(M.t(zA) - M.t(zG(k))));             % nearest AI switch in time
        col = 2 - fall;                                      % 1 = falling, 2 = rising
        sw(col)   = M.Ig(zA(j));
        sw(col+2) = M.t(zA(j)) - M.t(zG(k));
    end
    ang = @(m) mod(angle(mean(exp(1i*pi/180*M.th(m & ~isnan(M.th)))))*180/pi, 360);
    row = [gp, mean(M.D5(pp)), mean(M.D5(pn)), mean(M.AI(pp)), mean(M.AI(pn)), sw, ...
           mean(M.fw(pk), 'omitnan'), ang(pp), ang(pn)];
    fprintf('%-13s %6.3f %7.3f %7.3f %+6.2f %+6.2f | %+7.2f %+7.2f %+7.2f %+7.2f | %6.1f %6.0f %6.0f\n', M.run, row);
    fprintf(fid, '%s,%s\n', M.run, strjoin(arrayfun(@(v) sprintf('%.4g', v), row, 'UniformOutput', false), ','));
end
fclose(fid);
fprintf('(Isw = GIC where the saturating half-cycle switches; delay > 0 = switch after the GIC reversal)\n');

% ---- Fig 2: per-cycle metrics vs GIC, all runs ----
f2 = figure('Units','centimeters','Position',[2 2 16 12],'Color','w');
ttl = {'(a) D5 (71-141 Hz) RMS per cycle', '(b) Half-cycle asymmetry', ...
       '(c) Saturation pulse width', '(d) Rising vs falling GIC'};
for pnl = 1:4
    ax = axes('Position', [0.09 + mod(pnl-1,2)*0.48, 0.57 - floor((pnl-1)/2)*0.47, 0.38, 0.33]); hold(ax, 'on');
    for r = 1:numel(C)
        M = C(r); col = cLd(1 + (M.load == 100), :);
        switch pnl
            case 1, plot(ax, M.Ig, M.D5, '.', 'Color', col, 'MarkerSize', 3);
            case 2, plot(ax, M.Ig, M.AI, '.', 'Color', col, 'MarkerSize', 3);
            case 3, plot(ax, abs(M.Ig), M.fw, '.', 'Color', col, 'MarkerSize', 3);
            case 4
                if strcmp(M.run, figRun)
                    plot(ax, M.Ig(M.rise),  M.D5(M.rise),  '.', 'Color', cLab, 'MarkerSize', 3);
                    plot(ax, M.Ig(~M.rise), M.D5(~M.rise), '.', 'Color', cSim, 'MarkerSize', 3);
                end
        end
    end
    set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
        'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.15, 'Layer', 'top');
    title(ax, ttl{pnl}, 'FontWeight', 'normal', 'FontSize', fs+1);
    switch pnl
        case 1, ylabel(ax, 'D5 RMS (A)');  xlabel(ax, 'I_{GIC} (A)');
        case 2, ylabel(ax, 'AI');          xlabel(ax, 'I_{GIC} (A)'); ylim(ax, [-1.05 1.05]);
        case 3, ylabel(ax, 'FWHM (deg)');  xlabel(ax, '|I_{GIC}| (A)');
        case 4, ylabel(ax, 'D5 RMS (A)');  xlabel(ax, 'I_{GIC} (A)');
                text(ax, 0.04, 0.92, 'rising', 'Units', 'normalized', 'Color', cLab, 'FontSize', fs);
                text(ax, 0.04, 0.82, 'falling', 'Units', 'normalized', 'Color', cSim, 'FontSize', fs);
    end
    if pnl == 1
        text(ax, 0.04, 0.92, '50 \Omega',  'Units', 'normalized', 'Color', cLd(1,:), 'FontSize', fs);
        text(ax, 0.04, 0.82, '100 \Omega', 'Units', 'normalized', 'Color', cLd(2,:), 'FontSize', fs);
    end
end
save_fig(f2, fullfile(outDir, 'wav_cycle_metrics'));

%% ======================= PART 2 =======================
ser  = {'Igic_abs', 'I3_h2', 'V4rms', 'Q1'};
unit = {'A', '% of h1', 'V', 'var'};
P = struct('run', cell(1, numel(runs)), 'load', [], 'lab', [], 'sim', []);
found = false(1, numel(runs));
for r = 1:numel(runs)
    found(r) = exist(fullfile(resRoot, ['results_' runs{r}], 'results.mat'), 'file') == 2;
end
if ~any(found)
    error(['No results_Gic_*\\results.mat found in\n   %s\nSet resRoot (line 40) to the ' ...
           'folder where run_all.m wrote its results_Gic_* folders.'], resRoot);
end
for r = 1:numel(runs)
    f = fullfile(resRoot, ['results_' runs{r}], 'results.mat');
    if ~exist(f, 'file'), warning('Skipping %s (run run_all.m first)', f); continue; end
    R = load(f);
    src = {R.Ml, R.Ms}; nm = {'lab', 'sim'};
    for s = 1:2
        X = src{s};
        tg = (0:cfg.Tblock:X.t(end) - X.t(1))';            % uniform 0.5 s grid
        for q = 1:numel(ser)
            y = interp1(X.t - X.t(1), X.(ser{q}), tg, 'linear', 'extrap');
            m = modwtmra(modwt(y', wname, J2, 'reflection'), wname, 'reflection');
            P(r).(nm{s}).t = tg;
            P(r).(nm{s}).(ser{q}).x  = y;
            P(r).(nm{s}).(ser{q}).tr = m(end,:)';                     % A4 trend
            dd = sum(m(1:2,:), 1); kk = 11:numel(dd)-10;              % drop 5 s at each end (switch-on steps)
            P(r).(nm{s}).(ser{q}).fl = 1.4826*median(abs(dd(kk) - median(dd(kk))));  % robust RMS, 0.25-1 Hz
        end
        % lag of the I3 h2 trend behind the |GIC| trend (cross-correlation, +-10 s)
        a = P(r).(nm{s}).Igic_abs.tr; b = P(r).(nm{s}).I3_h2.tr;
        a = a - mean(a); b = b - mean(b); L = round(10/cfg.Tblock); cc = zeros(2*L+1,1);
        for l = -L:L
            if l >= 0, cc(l+L+1) = sum(a(1:end-l).*b(1+l:end));
            else,      cc(l+L+1) = sum(a(1-l:end).*b(1:end+l)); end
        end
        [~, il] = max(cc); P(r).(nm{s}).lag = (il - L - 1)*cfg.Tblock;
    end
    P(r).run = runs{r}; P(r).load = loadOf(r);
end

fid = fopen(fullfile(outDir, 'wav_part2.csv'), 'w');
ft  = fopen(fullfile(outDir, 'wav_part2.tex'), 'w');
fprintf(fid, 'Run,Lag_lab_s,Lag_sim_s,Fl_I3h2_lab,Fl_I3h2_sim,Fl_V4rms_lab,Fl_V4rms_sim,Fl_Q1_lab,Fl_Q1_sim\n');
fprintf(ft, '%% Requires \\usepackage{booktabs}\n\\begin{tabular}{lrrrrrrrr}\n\\toprule\n');
fprintf(ft, 'Run & \\multicolumn{2}{c}{$h_2$ lag (s)} & \\multicolumn{2}{c}{$I_3$ $h_2$ (\\%%)} & \\multicolumn{2}{c}{$V_4$ (V)} & \\multicolumn{2}{c}{$Q_1$ (var)} \\\\\n');
fprintf(ft, ' & Lab & Sim & Lab & Sim & Lab & Sim & Lab & Sim \\\\\n\\midrule\n');
fprintf('\n%-13s | %6s %6s | %16s | %16s | %16s\n', 'Run', 'lagL', 'lagS', 'fluct I3h2 L/S', 'fluct V4 L/S', 'fluct Q1 L/S');
for r = 1:numel(P)
    if isempty(P(r).run), continue; end
    l = P(r).lab; s = P(r).sim;
    v = [l.lag s.lag l.I3_h2.fl s.I3_h2.fl l.V4rms.fl s.V4rms.fl l.Q1.fl s.Q1.fl];
    fprintf('%-13s | %+6.1f %+6.1f | %7.3f %8.3f | %7.3f %8.3f | %7.2f %8.2f\n', P(r).run, v);
    fprintf(fid, '%s,%s\n', P(r).run, strjoin(arrayfun(@(x) sprintf('%.4g', x), v, 'UniformOutput', false), ','));
    fprintf(ft, '%s & %+.1f & %+.1f & %.2f & %.2f & %.2f & %.2f & %.1f & %.1f \\\\\n', ...
            strrep(P(r).run, '_', '\_'), v);
end
fprintf(ft, '\\bottomrule\n\\end{tabular}\n'); fclose(ft); fclose(fid);
fprintf('(fluct = robust RMS (1.4826 x MAD) of D1+D2, 0.25-1 Hz, first/last 5 s excluded; lag > 0 = h2 trend lags |GIC|)\n');

% ---- Fig 4: High-GIC runs, raw records + A4 trend, aligned on the |GIC| peak ----
pr = {P.run}; pr(cellfun(@isempty, pr)) = {''};
hr = find(strcmp(pr, 'Gic_High_50') | strcmp(pr, 'Gic_High_100'));
if ~isempty(hr)
    f4 = figure('Units','centimeters','Position',[2 2 16 13],'Color','w');
    sq = {'Igic_abs', 'I3_h2', 'V4rms'}; yl = {'|I_{GIC}| (A)', 'I_3 h_2 (% of h1)', 'V_4 RMS (V)'};
    for c = 1:numel(hr)
        r = hr(c);
        for q = 1:3
            ax = axes('Position', [0.10 + (c-1)*0.46, 0.65 - (q-1)*0.28, 0.38, 0.21]); hold(ax, 'on');
            for s = {'lab', 'sim'}
                X = P(r).(s{1}); [~, i0] = max(X.Igic_abs.tr); tt = X.t - X.t(i0);
                col = cLab; if strcmp(s{1}, 'sim'), col = cSim; end
                plot(ax, tt, X.(sq{q}).x,  '.', 'Color', 0.4*col + 0.6, 'MarkerSize', 4);
                plot(ax, tt, X.(sq{q}).tr, '-', 'Color', col, 'LineWidth', 1.2);
            end
            set(ax, 'FontName', fontName, 'FontSize', fs, 'Box', 'off', 'TickDir', 'out', ...
                'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.15, 'XLim', [-35 35]);
            if c == 1, ylabel(ax, yl{q}); end
            if q == 3, xlabel(ax, 'Time from |I_{GIC}| peak (s)'); else, set(ax, 'XTickLabel', []); end
            if q == 1, title(ax, sprintf('High GIC, %d \\Omega', P(r).load), 'FontWeight', 'normal', 'FontSize', fs+1); end
        end
    end
    ax0 = axes('Position', [0.10 0.955 0.8 0.04], 'Visible', 'off', 'XLim', [0 1], 'YLim', [0 1]); hold(ax0, 'on');
    plot(ax0, [0.20 0.26], [0.5 0.5], '-', 'Color', cLab, 'LineWidth', 1.2);
    text(ax0, 0.27, 0.5, 'Laboratory (dots: records, line: A4 trend)', 'FontSize', fs, 'FontName', fontName);
    plot(ax0, [0.62 0.68], [0.5 0.5], '-', 'Color', cSim, 'LineWidth', 1.2);
    text(ax0, 0.69, 0.5, 'Simulation', 'FontSize', fs, 'FontName', fontName);
    save_fig(f4, fullfile(outDir, 'wav_lab_vs_sim'));
end
fprintf('\nSaved figures and tables in %s\n', outDir);
