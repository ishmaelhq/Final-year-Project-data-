function sgtitle_compat(fig, s)
% 
    if exist('sgtitle', 'file'), sgtitle(fig, s);
    else, annotation(fig, 'textbox', [0 0.95 1 0.05], 'String', s, ...
            'EdgeColor', 'none', 'HorizontalAlignment', 'center'); end
end
