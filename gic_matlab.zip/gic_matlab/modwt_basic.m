function [W, VJ] = modwt_basic(x, J)
%MODWT_BASIC  Maximal-overlap DWT with db4, no toolbox needed.
%
%   [W, VJ] = modwt_basic(x, J)
%     W  : [J x N] wavelet coefficients, level 1 (highest band) .. J
%     VJ : [1 x N] scaling coefficients at level J (lowest band, incl. DC)
%
%   Pyramid algorithm with circular filtering done in the frequency domain
%   (Percival & Walden, 2000). Energy is preserved:
%     sum(x.^2) = sum(W(:).^2) + sum(VJ.^2)
%   Level j covers roughly fs/2^(j+1) .. fs/2^j.

    x = x(:)'; N = numel(x);
    % db4 scaling filter (8 taps, sum = sqrt(2))
    h = [0.2303778133088964  0.7148465705529154  0.6308807679298587 -0.0279837694168599 ...
        -0.1870348117190931  0.0308413818355607  0.0328830116668852 -0.0105974017850690];
    L = numel(h);
    g = fliplr(h) .* (-1).^(0:L-1);            % wavelet (high-pass) filter
    ht = h/sqrt(2); gt = g/sqrt(2);            % MODWT filters

    W = zeros(J, N);
    V = fft(x);
    for j = 1:J
        step = 2^(j-1);                        % upsample the filters by 2^(j-1)
        hj = zeros(1, N); gj = zeros(1, N);
        pos = mod((0:L-1)*step, N) + 1;
        for k = 1:L
            hj(pos(k)) = hj(pos(k)) + ht(k);
            gj(pos(k)) = gj(pos(k)) + gt(k);
        end
        Hj = fft(hj); Gj = fft(gj);
        W(j,:) = real(ifft(V .* Gj));
        V      = V .* Hj;
    end
    VJ = real(ifft(V));

    % shift each level so coefficients line up with the signal in time
    for j = 1:J
        Lj = (2^j - 1)*(L - 1) + 1;            % equivalent filter length at level j
        W(j,:) = circshift(W(j,:), [0, -round((Lj-1)/2)]);
    end
    LJ = (2^J - 1)*(L - 1) + 1;
    VJ = circshift(VJ, [0, -round((LJ-1)/2)]);
end
