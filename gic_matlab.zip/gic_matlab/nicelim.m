function y = nicelim(m)
%NICELIM  Round an axis maximum up to a clean value (1, 2, 2.5, 5 x 10^n), +5 % headroom.
    if m <= 0 || ~isfinite(m), y = 1; return; end
    m = 1.05*m;
    e = 10^floor(log10(m));
    for s = [1 2 2.5 5 10]
        if s*e >= m, y = s*e; return; end
    end
end
