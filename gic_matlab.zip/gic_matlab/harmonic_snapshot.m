function H = harmonic_snapshot(resFile, hmax)
%HARMONIC_SNAPSHOT  Per-phase harmonic spectra at peak (+) GIC and at baseline,
%   for one run, simulation and laboratory, on the same basis.
%
%   H = harmonic_snapshot('results_Gic_High_100\results.mat', 7)
%
%   Peak records
%     Sim : POSITIVE peak only  -> blocks with Igic >= peak_frac * max(Igic)
%     Lab : |GIC| peak (the WT1800 cannot see polarity; assumed positive)
%   Baseline records (GIC ~ 0)
%     Sim : the 3 blocks with the smallest |Igic|
%     Lab : records with Igic_abs <= base_frac * peak (at least 3)
%
%   Output (all [3 phases x hmax], RMS values, h = 1..hmax):
%     H.sim.peak.I3  (A)   H.sim.peak.V3 (V)   H.sim.peak.V4 (V)
%     H.sim.base.*         H.lab.peak.*        H.lab.base.*
%     H.gic.sim, H.gic.lab   GIC peak used (A)  |  H.label, H.Rload

    if nargin < 2, hmax = 7; end
    R = load(resFile);                 % cfg, Ms, Ml, T, Rs (saved by gic_compare)
    cfg = R.cfg; Ms = R.Ms; Ml = R.Ml; Rs = R.Rs;

    % ---------- simulation ----------
    kp = Ms.Igic >= cfg.peak_frac * max(Ms.Igic);          % positive peak
    [~, o] = sort(abs(Ms.Igic)); kb = false(size(Ms.Igic)); kb(o(1:3)) = true;
    for p = 1:3
        r3 = Rs.V3I3{p}; r4 = Rs.V4I4{p};
        H.sim.peak.I3(p,:) = mean(r3.Ih(kp, 1:hmax), 1);
        H.sim.peak.V3(p,:) = mean(r3.Uh(kp, 1:hmax), 1);
        H.sim.peak.V4(p,:) = mean(r4.Uh(kp, 1:hmax), 1);
        H.sim.base.I3(p,:) = mean(r3.Ih(kb, 1:hmax), 1);
        H.sim.base.V3(p,:) = mean(r3.Uh(kb, 1:hmax), 1);
        H.sim.base.V4(p,:) = mean(r4.Uh(kb, 1:hmax), 1);
    end
    H.gic.sim = mean(Ms.Igic(kp));

    % ---------- laboratory (per phase, straight from the WT1800 file) ----------
    L  = read_wt1800_csv(cfg.labCsv);
    lp = Ml.Igic_abs >= cfg.peak_frac * max(Ml.Igic_abs);
    lb = Ml.Igic_abs <= cfg.base_frac * max(Ml.Igic_abs);
    if nnz(lb) < 3, [~, o] = sort(Ml.Igic_abs); lb = false(size(lb)); lb(o(1:3)) = true; end
    for p = 1:3
        e3 = cfg.lab.e3(p); e4 = cfg.lab.e4(p);
        for h = 1:hmax
            I3 = lab_col(L, sprintf('I(k)-%d-%d', e3, h));
            V3 = lab_col(L, sprintf('U(k)-%d-%d', e3, h));
            V4 = lab_col(L, sprintf('U(k)-%d-%d', e4, h));
            H.lab.peak.I3(p,h) = mean(I3(lp));  H.lab.base.I3(p,h) = mean(I3(lb));
            H.lab.peak.V3(p,h) = mean(V3(lp));  H.lab.base.V3(p,h) = mean(V3(lb));
            H.lab.peak.V4(p,h) = mean(V4(lp));  H.lab.base.V4(p,h) = mean(V4(lb));
        end
    end
    H.gic.lab = mean(Ml.Igic_abs(lp));
    H.label = cfg.label;  H.Rload = cfg.Rload;
end
