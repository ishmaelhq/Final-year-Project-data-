function M = summarise_lab(L, cfg)
%SUMMARISE_LAB  WT1800 CSV -> per-record metrics (same fields as summarise_sim).
%
%   Element map (cfg.lab.e3 / cfg.lab.e4): default 1..3 = T2 primary (V3/I3),
%   4..6 = T2 output (V4/I4).
%
%   Fields (all [N x 1]):
%     t         time (s)
%     Igic      signed GIC  -> NaN for the lab (the WT1800 did not log its sign)
%     Igic_abs  sum over T2-primary phases of sqrt(Irms^2 - Iac^2)  (A)
%     V3rms V4rms I3rms I4rms      phase averages (V, A)
%     I3_h2..I3_h5                 T2 primary current harmonics, % of h1
%     V4_h2 V4_h3                  output voltage harmonics, % of h1
%     I3_thd V3_thd V4_thd I4_thd  THD-F (%), h2..cfg.hcmp, recomputed from h(k)
%     Q1        3-ph fundamental reactive power at the T2 primary (var)
%     P4        3-ph output active power (W), NaN if P was not stored

    e3 = cfg.lab.e3; e4 = cfg.lab.e4; hc = cfg.hcmp;
    c  = @(name) lab_col(L, name);
    U  = @(e,h) c(sprintf('U(k)-%d-%d', e, h));
    I  = @(e,h) c(sprintf('I(k)-%d-%d', e, h));

    M.t    = L.t;
    M.Igic = nan(size(L.t));
    M.Igic_abs = zeros(size(L.t));
    for e = e3
        M.Igic_abs = M.Igic_abs + sqrt(max(c(sprintf('Irms-%d',e)).^2 - c(sprintf('Iac-%d',e)).^2, 0));
    end

    M.V3rms = avg(@(e) c(sprintf('Urms-%d',e)), e3);
    M.V4rms = avg(@(e) c(sprintf('Urms-%d',e)), e4);
    M.I3rms = avg(@(e) c(sprintf('Irms-%d',e)), e3);
    M.I4rms = avg(@(e) c(sprintf('Irms-%d',e)), e4);
    for h = 2:5
        M.(sprintf('I3_h%d', h)) = avg(@(e) 100*I(e,h)./I(e,1), e3);
    end
    M.V4_h2 = avg(@(e) 100*U(e,2)./U(e,1), e4);
    M.V4_h3 = avg(@(e) 100*U(e,3)./U(e,1), e4);

    M.I3_thd = avg(@(e) thdF(I, e, hc), e3);
    M.V3_thd = avg(@(e) thdF(U, e, hc), e3);
    M.V4_thd = avg(@(e) thdF(U, e, hc), e4);
    M.I4_thd = avg(@(e) thdF(I, e, hc), e4);

    M.Q1 = zeros(size(L.t));
    for e = e3, M.Q1 = M.Q1 + c(sprintf('Q(k)-%d-1', e)); end

    if any(strcmp(L.names, sprintf('P-%d', e4(1))))
        M.P4 = zeros(size(L.t));
        for e = e4, M.P4 = M.P4 + c(sprintf('P-%d', e)); end
    else
        M.P4 = nan(size(L.t));
    end
end

function m = avg(f, els)
    m = 0;
    for e = els, m = m + f(e); end
    m = m/numel(els);
end

function y = thdF(H, e, hc)
    s = 0;
    for h = 2:hc, s = s + H(e,h).^2; end
    y = 100*sqrt(s)./H(e,1);
end
